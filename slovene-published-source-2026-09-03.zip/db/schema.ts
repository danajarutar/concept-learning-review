import { sql } from "drizzle-orm";
import { index, integer, sqliteTable, text, uniqueIndex } from "drizzle-orm/sqlite-core";

export const studySessions = sqliteTable(
  "study_sessions",
  {
    sessionId: text("session_id").primaryKey(),
    participantCode: text("participant_code").notNull(),
    variant: text("variant", { enum: ["adult", "child"] }).notNull(),
    schemaVersion: text("schema_version").notNull(),
    experimentVersion: text("experiment_version").notNull(),
    rulesetVersion: text("ruleset_version").notNull(),
    status: text("status").notNull(),
    currentTrial: integer("current_trial").notNull().default(0),
    lastCheckpointRevision: integer("last_checkpoint_revision").notNull().default(0),
    payloadJson: text("payload_json").notNull(),
    createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
    updatedAt: text("updated_at").notNull().default(sql`CURRENT_TIMESTAMP`),
    completedAt: text("completed_at"),
  },
  (table) => [
    index("idx_study_sessions_variant_status").on(table.variant, table.status),
    index("idx_study_sessions_updated_at").on(table.updatedAt),
  ],
);

export const studyCheckpoints = sqliteTable(
  "study_checkpoints",
  {
    checkpointId: text("checkpoint_id").primaryKey(),
    sessionId: text("session_id")
      .notNull()
      .references(() => studySessions.sessionId),
    checkpointType: text("checkpoint_type").notNull(),
    trialIndex: integer("trial_index"),
    sceneIndex: integer("scene_index"),
    checkpointRevision: integer("checkpoint_revision").notNull().default(0),
    clientTimestamp: text("client_timestamp").notNull(),
    payloadJson: text("payload_json").notNull(),
    createdAt: text("created_at").notNull().default(sql`CURRENT_TIMESTAMP`),
  },
  (table) => [
    index("idx_study_checkpoints_session_created").on(table.sessionId, table.createdAt),
    index("idx_study_checkpoints_created_id").on(table.createdAt, table.checkpointId),
    // Historical rows receive revision 0 during migration. New writes use a
    // positive monotonic revision, which must name exactly one payload.
    uniqueIndex("uq_study_checkpoints_session_revision")
      .on(table.sessionId, table.checkpointRevision)
      .where(sql`${table.checkpointRevision} > 0`),
  ],
);

/**
 * Database-assigned, immutable ordering for point-in-time exports.
 *
 * `study_checkpoints.created_at` has only second precision in D1 and
 * `checkpoint_id` is a random UUID, so that pair cannot separate an export
 * snapshot from a later insert made during the same second.  This surrogate
 * sequence is allocated transactionally with each checkpoint and is the only
 * export snapshot boundary.
 */
export const studyCheckpointExports = sqliteTable("study_checkpoint_exports", {
  sequence: integer("sequence").primaryKey({ autoIncrement: true }),
  checkpointId: text("checkpoint_id")
    .notNull()
    .unique()
    .references(() => studyCheckpoints.checkpointId),
});
