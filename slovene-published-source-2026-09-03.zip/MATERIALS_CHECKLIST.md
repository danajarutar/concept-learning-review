# Pregled eksperimentalnih prizorov

Ta seznam je ustvarjen iz trenutne različice eksperimenta. Oznaka **pozitivno** pomeni, da se usujejo rumene zvezdice in prizor sledi pravilu; **negativno** pomeni, da se zvezdice ne usujejo in prizor pravilu ne sledi. Vrstni red osmih generalizacijskih prizorov se v posamezni seji naključno premeša.

## Pravilo 1 — Dva lika sta enake barve

| Gradivo | Oznaka | Liki v prizoru |
|---|---|---|
| Začetni primer | pozitivno | majhen rdeč trikotnik; velik rdeč kvadrat; velik moder krog |
| r1-p1 | pozitivno | majhen rdeč trikotnik; velik rdeč krog |
| r1-p2 | pozitivno | srednji zelen kvadrat; majhen moder krog; velik zelen trikotnik |
| r1-p3 | pozitivno | majhen moder kvadrat; srednji moder trikotnik; velik rdeč krog |
| r1-p4 | pozitivno | velik zelen krog; majhen zelen krog; srednji moder kvadrat |
| r1-n1 | negativno | majhen rdeč trikotnik |
| r1-n2 | negativno | velik rdeč kvadrat; velik moder kvadrat |
| r1-n3 | negativno | majhen rdeč krog; srednji moder krog; velik zelen trikotnik |
| r1-n4 | negativno | majhen zelen kvadrat; velik moder trikotnik |

## Pravilo 2 — Vsi liki so enake velikosti

| Gradivo | Oznaka | Liki v prizoru |
|---|---|---|
| Začetni primer | pozitivno | srednji rdeč trikotnik; srednji moder krog; srednji zelen kvadrat |
| r2-p1 | pozitivno | majhen rdeč trikotnik; majhen moder krog |
| r2-p2 | pozitivno | velik zelen kvadrat; velik rdeč krog |
| r2-p3 | pozitivno | srednji rdeč krog; srednji zelen trikotnik; srednji moder kvadrat |
| r2-p4 | pozitivno | velik moder trikotnik; velik rdeč kvadrat; velik moder krog |
| r2-n1 | negativno | majhen rdeč trikotnik; srednji moder krog |
| r2-n2 | negativno | velik zelen kvadrat; majhen zelen kvadrat |
| r2-n3 | negativno | majhen moder krog; srednji rdeč trikotnik; velik zelen kvadrat |
| r2-n4 | negativno | velik rdeč krog; velik moder trikotnik; srednji zelen kvadrat |

## Pravilo 3 — V prizoru sta trikotnik in krog

| Gradivo | Oznaka | Liki v prizoru |
|---|---|---|
| Začetni primer | pozitivno | majhen zelen trikotnik; velik zelen krog; velik moder trikotnik |
| r3-p1 | pozitivno | majhen rdeč trikotnik; velik moder krog |
| r3-p2 | pozitivno | srednji zelen krog; srednji zelen trikotnik; velik rdeč kvadrat |
| r3-p3 | pozitivno | majhen moder trikotnik; majhen moder krog; majhen zelen krog |
| r3-p4 | pozitivno | velik rdeč kvadrat; velik zelen trikotnik; srednji moder krog |
| r3-n1 | negativno | majhen rdeč trikotnik; srednji moder kvadrat |
| r3-n2 | negativno | velik zelen krog; majhen rdeč kvadrat |
| r3-n3 | negativno | srednji moder kvadrat; majhen zelen kvadrat |
| r3-n4 | negativno | velik rdeč trikotnik; majhen moder trikotnik |

## Pravilo 4 — Natanko en lik je moder

| Gradivo | Oznaka | Liki v prizoru |
|---|---|---|
| Začetni primer | pozitivno | majhen moder krog; majhen rdeč kvadrat; velik rdeč trikotnik |
| r4-p1 | pozitivno | majhen moder trikotnik |
| r4-p2 | pozitivno | velik moder krog; majhen rdeč kvadrat |
| r4-p3 | pozitivno | srednji zelen trikotnik; srednji moder kvadrat; velik rdeč krog |
| r4-p4 | pozitivno | majhen rdeč krog; velik zelen kvadrat; majhen moder trikotnik |
| r4-n1 | negativno | majhen rdeč trikotnik |
| r4-n2 | negativno | velik zelen krog; srednji rdeč kvadrat |
| r4-n3 | negativno | majhen moder trikotnik; velik moder krog |
| r4-n4 | negativno | srednji moder kvadrat; majhen rdeč krog; velik moder trikotnik |

## Pravilo 5 — V prizoru je majhen zelen kvadrat

| Gradivo | Oznaka | Liki v prizoru |
|---|---|---|
| Začetni primer | pozitivno | majhen zelen kvadrat; velik zelen krog; majhen moder trikotnik |
| r5-p1 | pozitivno | majhen zelen kvadrat |
| r5-p2 | pozitivno | majhen zelen kvadrat; velik moder krog |
| r5-p3 | pozitivno | srednji rdeč trikotnik; majhen zelen kvadrat; velik zelen krog |
| r5-p4 | pozitivno | majhen moder krog; majhen zelen kvadrat; velik rdeč kvadrat |
| r5-n1 | negativno | majhen zelen krog |
| r5-n2 | negativno | velik zelen kvadrat; majhen moder kvadrat |
| r5-n3 | negativno | majhen rdeč kvadrat; srednji zelen trikotnik |
| r5-n4 | negativno | majhen moder trikotnik; velik zelen krog; srednji rdeč kvadrat |

## Prikazno pravilo, ki ni del glavne igre

Interaktivni prikaz uporablja pravilo **V prizoru sta natanko dva lika.** Pred obema prikaznima konstrukcijama je viden pozitiven prizor z natanko dvema likoma. Raziskovalec(ka) sestavi dva prikazna prizora ter pri obeh zapiše pravilo in izbere najmanj en opis operacije, nato pa med osmimi novimi prizori prikaže izbiro vseh prizorov z natanko dvema likoma. Ti podatki se beležijo v ločenem polju `practice_demo` in niso del `trials`, `active_tests` ali glavnih `generalisation_probes`.
