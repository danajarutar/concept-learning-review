import type { Metadata } from "next";
import { ZendoStudy } from "../components/ZendoStudy";

export const metadata: Metadata = {
  title: "Zendo za odrasle",
  description: "Raziskovalna igra Zendo v slovenščini za odrasle udeležence.",
};

export default function AdultStudyPage() {
  return <ZendoStudy variant="adult" />;
}
