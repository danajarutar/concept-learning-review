import {
  and,
  asc,
  desc,
  eq,
  gt,
  isNull,
  lte,
  notExists,
  or,
} from "drizzle-orm";
import { alias } from "drizzle-orm/sqlite-core";
import { env } from "cloudflare:workers";
import { getDb } from "../../../db";
import {
  studyCheckpointExports,
  studyCheckpoints,
  studySessions,
} from "../../../db/schema";
import { validateStudySessionPayload } from "../../lib/checkpoint-contract";
import { parseStudySessionPayload } from "../../lib/session-payload";

export const runtime = "edge";

const PAGE_LIMIT = 25;
const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

interface ExportCursor {
  session_id: string;
}

interface ExportSnapshot {
  sequence: number;
}

function encodeToken(value: ExportCursor | ExportSnapshot): string {
  return btoa(JSON.stringify(value));
}

function decodeCursor(value: string | null): ExportCursor | null {
  if (value === null || value === "") return null;
  if (value.length > 256) throw new Error("cursor je predolg.");
  let parsed: unknown;
  try {
    parsed = JSON.parse(atob(value));
  } catch {
    throw new Error("cursor ni veljaven.");
  }
  if (
    !parsed ||
    typeof parsed !== "object" ||
    Array.isArray(parsed) ||
    !UUID_PATTERN.test((parsed as ExportCursor).session_id)
  ) {
    throw new Error("cursor ni veljaven.");
  }
  return parsed as ExportCursor;
}

function decodeSnapshot(value: string | null): ExportSnapshot | null {
  if (value === null || value === "") return null;
  if (value.length > 256) throw new Error("snapshot je predolg.");
  let parsed: unknown;
  try {
    parsed = JSON.parse(atob(value));
  } catch {
    throw new Error("snapshot ni veljaven.");
  }
  if (
    !parsed ||
    typeof parsed !== "object" ||
    Array.isArray(parsed) ||
    !Number.isSafeInteger((parsed as ExportSnapshot).sequence) ||
    (parsed as ExportSnapshot).sequence < 1
  ) {
    throw new Error("snapshot ni veljaven.");
  }
  return parsed as ExportSnapshot;
}

function checkpointSession(
  payloadJson: string,
  expectedSessionId: string,
): unknown {
  const envelope = parseStudySessionPayload(payloadJson);
  if (
    !envelope ||
    typeof envelope !== "object" ||
    Array.isArray(envelope) ||
    !("session" in envelope)
  ) {
    throw new Error("Shranjeni kontrolni zapis nima seje.");
  }
  const session = (envelope as { session: unknown }).session;
  validateStudySessionPayload(session);
  if (session.session_id !== expectedSessionId) {
    throw new Error("Kontrolni zapis in seja nimata iste identitete.");
  }
  return session;
}

export async function GET(request: Request) {
  const suppliedKey = request.headers.get("x-zendo-export-key") ?? "";
  const expectedKey = typeof env.EXPORT_KEY === "string" ? env.EXPORT_KEY : "";
  if (!expectedKey || suppliedKey !== expectedKey) {
    return Response.json({ error: "Dostop ni dovoljen." }, { status: 401 });
  }

  const url = new URL(request.url);
  let cursor: ExportCursor | null;
  let suppliedSnapshot: ExportSnapshot | null;
  try {
    cursor = decodeCursor(url.searchParams.get("cursor"));
    suppliedSnapshot = decodeSnapshot(url.searchParams.get("snapshot"));
  } catch (error) {
    const detail = error instanceof Error ? error.message : "Neveljavna zahteva.";
    return Response.json({ error: "Izvozni kazalec ni veljaven.", detail }, { status: 400 });
  }
  if (cursor && !suppliedSnapshot) {
    return Response.json({ error: "Cursor zahteva žig izvoza." }, { status: 400 });
  }

  try {
    const db = getDb();
    if (suppliedSnapshot) {
      // A merely well-formed integer is not a snapshot: accepting a future
      // sequence would let checkpoints inserted between pages enter the same
      // export.  Require the opaque token to name an allocated boundary.
      const allocatedBoundary = await db
        .select({ sequence: studyCheckpointExports.sequence })
        .from(studyCheckpointExports)
        .where(eq(studyCheckpointExports.sequence, suppliedSnapshot.sequence))
        .limit(1);
      if (allocatedBoundary.length !== 1) {
        return Response.json({ error: "Izvozni žig ne obstaja." }, { status: 400 });
      }
    }
    if (!suppliedSnapshot) {
      // Every session must be recoverable from immutable checkpoint history.
      // A session row without a checkpoint indicates an interrupted/corrupt
      // write and must not silently disappear from the research export.
      const orphan = await db
        .select({ sessionId: studySessions.sessionId })
        .from(studySessions)
        .leftJoin(
          studyCheckpoints,
          eq(studySessions.sessionId, studyCheckpoints.sessionId),
        )
        .where(isNull(studyCheckpoints.checkpointId))
        .limit(1);
      if (orphan.length > 0) {
        throw new Error("Seja brez kontrolnega zapisa.");
      }
      const checkpointWithoutBoundary = await db
        .select({ checkpointId: studyCheckpoints.checkpointId })
        .from(studyCheckpoints)
        .leftJoin(
          studyCheckpointExports,
          eq(studyCheckpoints.checkpointId, studyCheckpointExports.checkpointId),
        )
        .where(isNull(studyCheckpointExports.sequence))
        .limit(1);
      if (checkpointWithoutBoundary.length > 0) {
        throw new Error("Kontrolni zapis nima izvozne meje.");
      }
    }

    let snapshot = suppliedSnapshot;
    if (!snapshot) {
      const newest = await db
        .select({
          sequence: studyCheckpointExports.sequence,
        })
        .from(studyCheckpointExports)
        .orderBy(desc(studyCheckpointExports.sequence))
        .limit(1);
      snapshot = newest.length
        ? { sequence: newest[0].sequence }
        : null;
    }

    if (!snapshot) {
      return Response.json(
        { sessions: [], next_cursor: null, snapshot: null },
        { headers: { "cache-control": "no-store" } },
      );
    }

    const newer = alias(studyCheckpoints, "newer_checkpoint");
    const newerExport = alias(studyCheckpointExports, "newer_export_boundary");
    const atOrBeforeSnapshot = lte(studyCheckpointExports.sequence, snapshot.sequence);
    const newerAtOrBeforeSnapshot = lte(newerExport.sequence, snapshot.sequence);
    const chronologicallyNewer = or(
      gt(newer.checkpointRevision, studyCheckpoints.checkpointRevision),
      and(
        eq(newer.checkpointRevision, studyCheckpoints.checkpointRevision),
        gt(newerExport.sequence, studyCheckpointExports.sequence),
      ),
    );
    const laterCheckpointInSnapshot = db
      .select({ checkpointId: newer.checkpointId })
      .from(newer)
      .innerJoin(newerExport, eq(newer.checkpointId, newerExport.checkpointId))
      .where(and(
        eq(newer.sessionId, studyCheckpoints.sessionId),
        newerAtOrBeforeSnapshot,
        chronologicallyNewer,
      ));
    const afterCursor = cursor
      ? gt(studyCheckpoints.sessionId, cursor.session_id)
      : undefined;
    const latestInSnapshot = and(
      atOrBeforeSnapshot,
      notExists(laterCheckpointInSnapshot),
    );
    const rows = await db
      .select({
        sessionId: studyCheckpoints.sessionId,
        payloadJson: studyCheckpoints.payloadJson,
      })
      .from(studyCheckpoints)
      .innerJoin(
        studyCheckpointExports,
        eq(studyCheckpoints.checkpointId, studyCheckpointExports.checkpointId),
      )
      .where(afterCursor ? and(latestInSnapshot, afterCursor) : latestInSnapshot)
      .orderBy(asc(studyCheckpoints.sessionId))
      .limit(PAGE_LIMIT + 1);
    const pageRows = rows.slice(0, PAGE_LIMIT);
    const last = pageRows.at(-1);

    return Response.json(
      {
        sessions: pageRows.map((row) => checkpointSession(row.payloadJson, row.sessionId)),
        next_cursor: rows.length > PAGE_LIMIT && last
          ? encodeToken({ session_id: last.sessionId })
          : null,
        snapshot: encodeToken(snapshot),
      },
      { headers: { "cache-control": "no-store" } },
    );
  } catch {
    return Response.json({ error: "Izvoza ni mogoče pripraviti." }, { status: 500 });
  }
}
