import {
  studyCheckpointExports,
  studyCheckpoints,
  studySessions,
} from "../../../db/schema";
import { getDb } from "../../../db";
import {
  immutableSessionIdentity,
  MAX_CHECKPOINT_BODY_BYTES,
  sessionStatusRank,
  validateCheckpointRequest,
  validateSessionProgression,
  validateStudySessionPayload,
} from "../../lib/checkpoint-contract";
import {
  parseStudySessionPayload,
  serializeStudySessionPayload,
} from "../../lib/session-payload";
import { and, eq, exists, sql } from "drizzle-orm";
import type { StudySession } from "../../lib/experiment";

export const runtime = "edge";

function validateStoredSession(
  payloadJson: string,
  columns: {
    participantCode: string;
    variant: "adult" | "child";
    schemaVersion: string;
    experimentVersion: string;
    rulesetVersion: string;
    status: string;
  },
): StudySession {
  const stored = parseStudySessionPayload(payloadJson);
  validateStudySessionPayload(stored);
  if (
    stored.participant_code !== columns.participantCode ||
    stored.variant !== columns.variant ||
    stored.schema_version !== columns.schemaVersion ||
    stored.experiment_version !== columns.experimentVersion ||
    stored.ruleset_version !== columns.rulesetVersion ||
    stored.status !== columns.status
  ) {
    throw new Error("Shranjena seja se ne ujema z indeksiranimi stolpci.");
  }
  return stored;
}

export async function POST(request: Request) {
  try {
    const raw = await request.text();
    if (new TextEncoder().encode(raw).byteLength > MAX_CHECKPOINT_BODY_BYTES) {
      return Response.json({ error: "Zapis je prevelik." }, { status: 413 });
    }

    let parsed: unknown;
    try {
      parsed = JSON.parse(raw) as unknown;
    } catch {
      return Response.json({ error: "Neveljaven JSON." }, { status: 400 });
    }
    let body;
    try {
      body = validateCheckpointRequest(parsed);
    } catch (error) {
      const detail = error instanceof Error ? error.message : "Neveljavna vsebina.";
      return Response.json(
        { error: "Neveljavna shema kontrolnega zapisa.", detail },
        { status: 400 },
      );
    }
    const session = body.session;

    const now = new Date().toISOString();
    const currentTrial = Math.max(session.trials.length - 1, 0);
    const db = getDb();

    const duplicate = await db
      .select({
        sessionId: studyCheckpoints.sessionId,
        checkpointRevision: studyCheckpoints.checkpointRevision,
        payloadJson: studyCheckpoints.payloadJson,
      })
      .from(studyCheckpoints)
      .where(eq(studyCheckpoints.checkpointId, body.checkpoint_id))
      .limit(1);
    if (duplicate.length > 0) {
      if (
        duplicate[0].sessionId !== session.session_id ||
        duplicate[0].checkpointRevision !== body.checkpoint_revision ||
        duplicate[0].payloadJson !== raw
      ) {
        return Response.json({ error: "Kontrolni zapis ima nasprotujočo vsebino." }, { status: 409 });
      }
      const owner = await db
        .select({
          lastCheckpointRevision: studySessions.lastCheckpointRevision,
          payloadJson: studySessions.payloadJson,
        })
        .from(studySessions)
        .where(eq(studySessions.sessionId, session.session_id))
        .limit(1);
      try {
        if (owner.length !== 1 || owner[0].lastCheckpointRevision < body.checkpoint_revision) {
          throw new Error("Checkpoint has not advanced its session.");
        }
        const current = parseStudySessionPayload(owner[0].payloadJson);
        validateStudySessionPayload(current);
        validateSessionProgression(session, current);
      } catch {
        return Response.json({ error: "Kontrolni zapis je zastarel." }, { status: 409 });
      }
      return Response.json({ ok: true, deduplicated: true, saved_at: now });
    }

    const existing = await db
      .select({
        participantCode: studySessions.participantCode,
        variant: studySessions.variant,
        schemaVersion: studySessions.schemaVersion,
        experimentVersion: studySessions.experimentVersion,
        rulesetVersion: studySessions.rulesetVersion,
        status: studySessions.status,
        lastCheckpointRevision: studySessions.lastCheckpointRevision,
        payloadJson: studySessions.payloadJson,
      })
      .from(studySessions)
      .where(eq(studySessions.sessionId, session.session_id))
      .limit(1);
    if (existing.length > 0) {
      let storedSession: StudySession;
      try {
        storedSession = validateStoredSession(existing[0].payloadJson, existing[0]);
      } catch {
        return Response.json({ error: "Shranjena seja je poškodovana." }, { status: 500 });
      }
      if (
        existing[0].participantCode !== session.participant_code ||
        existing[0].variant !== session.variant ||
        existing[0].schemaVersion !== session.schema_version ||
        existing[0].experimentVersion !== session.experiment_version ||
        existing[0].rulesetVersion !== session.ruleset_version ||
        immutableSessionIdentity(storedSession) !== immutableSessionIdentity(session)
      ) {
        return Response.json({ error: "Identiteta seje se ne ujema." }, { status: 409 });
      }
      if (sessionStatusRank(session.status) < sessionStatusRank(storedSession.status)) {
        return Response.json({ error: "Status seje se ne sme vrniti nazaj." }, { status: 409 });
      }
      try {
        validateSessionProgression(storedSession, session);
      } catch {
        return Response.json({ error: "Vsebina seje ni veljavna nadaljnja različica." }, { status: 409 });
      }
      if (body.checkpoint_revision <= existing[0].lastCheckpointRevision) {
        return Response.json({ error: "Kontrolni zapis je zastarel." }, { status: 409 });
      }
    }

    await db
      .insert(studySessions)
      .values({
        sessionId: session.session_id,
        participantCode: session.participant_code,
        variant: session.variant,
        schemaVersion: session.schema_version,
        experimentVersion: session.experiment_version,
        rulesetVersion: session.ruleset_version,
        status: session.status,
        currentTrial,
        // Claim immutable identity first. The revision is advanced only after
        // the matching checkpoint row has been durably claimed as well.
        lastCheckpointRevision: 0,
        payloadJson: serializeStudySessionPayload(session),
        updatedAt: now,
        completedAt: session.completed_at ?? null,
      })
      .onConflictDoNothing({ target: studySessions.sessionId });

    // Re-read after INSERT ... ON CONFLICT so two first writes cannot race past
    // the immutable-identity check performed above.
    const claimed = await db
      .select({
        participantCode: studySessions.participantCode,
        variant: studySessions.variant,
        schemaVersion: studySessions.schemaVersion,
        experimentVersion: studySessions.experimentVersion,
        rulesetVersion: studySessions.rulesetVersion,
        status: studySessions.status,
        lastCheckpointRevision: studySessions.lastCheckpointRevision,
        payloadJson: studySessions.payloadJson,
      })
      .from(studySessions)
      .where(eq(studySessions.sessionId, session.session_id))
      .limit(1);
    let claimedSession: StudySession;
    try {
      if (claimed.length !== 1) throw new Error("Manjkajoča seja.");
      claimedSession = validateStoredSession(claimed[0].payloadJson, claimed[0]);
    } catch {
      return Response.json({ error: "Shranjena seja je poškodovana." }, { status: 500 });
    }
    if (immutableSessionIdentity(claimedSession) !== immutableSessionIdentity(session)) {
      return Response.json({ error: "Identiteta seje se ne ujema." }, { status: 409 });
    }
    if (sessionStatusRank(session.status) < sessionStatusRank(claimedSession.status)) {
      return Response.json({ error: "Status seje se ne sme vrniti nazaj." }, { status: 409 });
    }
    try {
      validateSessionProgression(claimedSession, session);
    } catch {
      return Response.json({ error: "Vsebina seje ni veljavna nadaljnja različica." }, { status: 409 });
    }
    if (body.checkpoint_revision <= claimed[0].lastCheckpointRevision) {
      return Response.json({ error: "Kontrolni zapis je zastarel." }, { status: 409 });
    }

    // Claim the checkpoint only while the exact parent snapshot is still
    // current.  A stale branch therefore inserts zero rows; it cannot leave a
    // rejected checkpoint behind if the worker terminates after the batch.
    const checkpointInsert = db
      .insert(studyCheckpoints)
      .select(sql`
        SELECT
          ${body.checkpoint_id},
          ${session.session_id},
          ${body.checkpoint_type},
          ${body.trial_index ?? null},
          ${body.scene_index ?? null},
          ${body.checkpoint_revision},
          ${body.client_timestamp},
          ${raw},
          CURRENT_TIMESTAMP
        FROM ${studySessions}
        WHERE ${studySessions.sessionId} = ${session.session_id}
          AND ${studySessions.lastCheckpointRevision} = ${claimed[0].lastCheckpointRevision}
          AND ${studySessions.payloadJson} = ${claimed[0].payloadJson}
      `)
      .onConflictDoNothing();

    // Allocate a database-ordered export boundary in the same transaction as
    // the checkpoint. Random UUIDs and second-resolution D1 timestamps cannot
    // define a race-free point-in-time snapshot.
    const checkpointExportInsert = db
      .insert(studyCheckpointExports)
      .select(sql`
        SELECT NULL, ${studyCheckpoints.checkpointId}
        FROM ${studyCheckpoints}
        WHERE ${studyCheckpoints.checkpointId} = ${body.checkpoint_id}
          AND ${studyCheckpoints.sessionId} = ${session.session_id}
          AND ${studyCheckpoints.checkpointRevision} = ${body.checkpoint_revision}
          AND ${studyCheckpoints.payloadJson} = ${raw}
      `)
      .onConflictDoNothing({ target: studyCheckpointExports.checkpointId });

    const exactCheckpointClaim = db
      .select({ checkpointId: studyCheckpoints.checkpointId })
      .from(studyCheckpoints)
      .where(and(
        eq(studyCheckpoints.checkpointId, body.checkpoint_id),
        eq(studyCheckpoints.sessionId, session.session_id),
        eq(studyCheckpoints.checkpointRevision, body.checkpoint_revision),
        eq(studyCheckpoints.payloadJson, raw),
      ));

    const sessionUpdate = db
      .update(studySessions)
      .set({
        status: session.status,
        currentTrial,
        lastCheckpointRevision: body.checkpoint_revision,
        payloadJson: serializeStudySessionPayload(session),
        updatedAt: now,
        completedAt: session.completed_at ?? null,
      })
      .where(and(
        eq(studySessions.sessionId, session.session_id),
        // Compare-and-swap the exact snapshot re-read above. Two valid
        // branches can both have larger revisions; only the branch whose
        // parent payload/revision is still current may advance the session.
        eq(studySessions.lastCheckpointRevision, claimed[0].lastCheckpointRevision),
        eq(studySessions.payloadJson, claimed[0].payloadJson),
        exists(exactCheckpointClaim),
      ));

    // D1 batches are transactional. The session can advance only if this
    // request owns the exact checkpoint ID/revision/payload claimed above.
    await db.batch([checkpointInsert, checkpointExportInsert, sessionUpdate]);

    const storedCheckpoint = await db
      .select({
        sessionId: studyCheckpoints.sessionId,
        checkpointRevision: studyCheckpoints.checkpointRevision,
        payloadJson: studyCheckpoints.payloadJson,
      })
      .from(studyCheckpoints)
      .where(eq(studyCheckpoints.checkpointId, body.checkpoint_id))
      .limit(1);
    if (
      storedCheckpoint.length !== 1 ||
      storedCheckpoint[0].sessionId !== session.session_id ||
      storedCheckpoint[0].checkpointRevision !== body.checkpoint_revision ||
      storedCheckpoint[0].payloadJson !== raw
    ) {
      return Response.json({ error: "Kontrolni zapis ima nasprotujočo vsebino." }, { status: 409 });
    }

    const revisionOwner = await db
      .select({
        checkpointId: studyCheckpoints.checkpointId,
        payloadJson: studyCheckpoints.payloadJson,
      })
      .from(studyCheckpoints)
      .where(and(
        eq(studyCheckpoints.sessionId, session.session_id),
        eq(studyCheckpoints.checkpointRevision, body.checkpoint_revision),
      ))
      .limit(1);
    if (
      revisionOwner.length !== 1 ||
      revisionOwner[0].checkpointId !== body.checkpoint_id ||
      revisionOwner[0].payloadJson !== raw
    ) {
      return Response.json({ error: "Revizija kontrolnega zapisa ima nasprotujočo vsebino." }, { status: 409 });
    }

    const committed = await db
      .select({
        lastCheckpointRevision: studySessions.lastCheckpointRevision,
        payloadJson: studySessions.payloadJson,
      })
      .from(studySessions)
      .where(eq(studySessions.sessionId, session.session_id))
      .limit(1);
    const expectedPayload = serializeStudySessionPayload(session);
    if (
      committed.length === 1 &&
      committed[0].lastCheckpointRevision === body.checkpoint_revision &&
      committed[0].payloadJson === expectedPayload
    ) {
      return Response.json({ ok: true, saved_at: now });
    }
    if (committed.length === 1 && committed[0].lastCheckpointRevision > body.checkpoint_revision) {
      try {
        const current = parseStudySessionPayload(committed[0].payloadJson);
        validateStudySessionPayload(current);
        validateSessionProgression(session, current);
        return Response.json({ ok: true, superseded: true, saved_at: now });
      } catch {
        // A higher divergent branch did not descend from this request.
      }
    }

    return Response.json({ error: "Kontrolni zapis je zastarel." }, { status: 409 });
  } catch {
    return Response.json({ error: "Shranjevanje trenutno ni mogoče." }, { status: 500 });
  }
}
