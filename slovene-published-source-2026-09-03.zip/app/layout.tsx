import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import { headers } from "next/headers";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export async function generateMetadata(): Promise<Metadata> {
  const requestHeaders = await headers();
  const host = requestHeaders.get("x-forwarded-host") ?? requestHeaders.get("host") ?? "localhost:3000";
  const protocol = requestHeaders.get("x-forwarded-proto") ?? (host.startsWith("localhost") ? "http" : "https");
  const origin = `${protocol}://${host}`;
  return {
    metadataBase: new URL(origin),
    title: {
      default: "Zendo — raziskava učenja pojmov",
      template: "%s | Zendo",
    },
    description: "Poenostavljena igra Zendo za raziskavo učenja pojmov pri odraslih in otrocih.",
    icons: { icon: "/favicon.ico", shortcut: "/favicon.ico" },
    openGraph: {
      title: "Zendo — odkrij skrito pravilo",
      description: "Poenostavljena igra Zendo za raziskavo učenja pojmov.",
      type: "website",
      images: [{ url: `${origin}/og.png`, width: 1536, height: 1024, alt: "Zendo — odkrij skrito pravilo" }],
    },
    twitter: {
      card: "summary_large_image",
      title: "Zendo — odkrij skrito pravilo",
      description: "Poenostavljena igra Zendo za raziskavo učenja pojmov.",
      images: [`${origin}/og.png`],
    },
  };
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="sl">
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        {children}
      </body>
    </html>
  );
}
