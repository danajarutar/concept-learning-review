import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Zendo — raziskava učenja pojmov",
  description: "Poenostavljena igra Zendo za raziskavo učenja pojmov.",
};

export default function Home() {
  return (
    <main className="welcome-shell">
      <section className="welcome-card route-card">
        <div className="brand-mark" aria-hidden="true">★</div>
        <p className="eyebrow">Raziskava učenja pojmov</p>
        <h1>Izberite različico igre Zendo</h1>
        <p className="lead">Udeležencem pošljite neposredno povezavo do ustrezne različice.</p>
        <div className="route-links">
          <a className="button button--primary" href="/odrasli">Različica za odrasle</a>
          <a className="button button--secondary" href="/otroci">Različica za otroke</a>
        </div>
      </section>
    </main>
  );
}
