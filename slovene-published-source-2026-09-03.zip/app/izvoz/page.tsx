"use client";

import { useState } from "react";

export default function ExportPage() {
  const [key, setKey] = useState("");
  const [state, setState] = useState<"idle" | "loading" | "error">("idle");
  const [message, setMessage] = useState("");

  async function download() {
    if (!key.trim()) return;
    setState("loading");
    setMessage("");
    try {
      const ndjsonLines: string[] = [];
      const seenSessionIds = new Set<string>();
      const seenCursors = new Set<string>();
      let cursor: string | null = null;
      let snapshot: string | null = null;
      let firstPage = true;
      while (firstPage || cursor !== null) {
        const query = new URLSearchParams();
        if (cursor) query.set("cursor", cursor);
        if (snapshot) query.set("snapshot", snapshot);
        const response = await fetch(`/api/export?${query}`, {
          headers: { "x-zendo-export-key": key.trim() },
          cache: "no-store",
        });
        if (!response.ok) throw new Error("Dostop ni dovoljen ali podatkov ni mogoče prebrati.");
        const body = (await response.json()) as {
          sessions: unknown[];
          next_cursor: string | null;
          snapshot: string | null;
        };
        if (!Array.isArray(body.sessions) || (snapshot !== null && body.snapshot !== snapshot)) {
          throw new Error("Izvozni posnetek se je med prenosom spremenil.");
        }
        snapshot = body.snapshot;
        for (const session of body.sessions) {
          const id = session && typeof session === "object"
            ? (session as { session_id?: unknown }).session_id
            : undefined;
          if (typeof id !== "string" || seenSessionIds.has(id)) {
            throw new Error("Izvoz vsebuje manjkajočo ali podvojeno identiteto seje.");
          }
          seenSessionIds.add(id);
          ndjsonLines.push(JSON.stringify(session));
        }
        if (body.next_cursor !== null && typeof body.next_cursor !== "string") {
          throw new Error("Izvozni strežnik je vrnil neveljaven kazalec.");
        }
        if (body.next_cursor !== null) {
          if (seenCursors.has(body.next_cursor)) {
            throw new Error("Izvozni strežnik je ponovil kazalec in prenos je bil ustavljen.");
          }
          seenCursors.add(body.next_cursor);
        }
        cursor = body.next_cursor;
        firstPage = false;
      }
      const ndjson = ndjsonLines.join("\n");
      const blob = new Blob([ndjson], { type: "application/x-ndjson" });
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = `zendo-seje-${new Date().toISOString().slice(0, 10)}.ndjson`;
      anchor.click();
      URL.revokeObjectURL(url);
      setState("idle");
      setMessage(`Prenesenih sej: ${seenSessionIds.size}.`);
    } catch (error) {
      setState("error");
      setMessage(error instanceof Error ? error.message : "Prenos ni uspel.");
    }
  }

  return (
    <main className="welcome-shell">
      <section className="welcome-card">
        <p className="eyebrow">Raziskovalni izvoz</p>
        <h1>Prenos podatkov Zendo</h1>
        <p className="lead">Ta stran ni povezana z udeležensko različico. Za izvoz je potrebno raziskovalno geslo.</p>
        <div className="stack-form">
          <label>Raziskovalno geslo<input type="password" value={key} onChange={(event) => setKey(event.target.value)} autoComplete="current-password" /></label>
          <button type="button" className="button button--primary" onClick={download} disabled={!key.trim() || state === "loading"}>{state === "loading" ? "Pripravljam izvoz …" : "Prenesi vse seje (.ndjson)"}</button>
          {message ? <p className={state === "error" ? "form-notice" : "tip-box"}>{message}</p> : null}
        </div>
      </section>
    </main>
  );
}
