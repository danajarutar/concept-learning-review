import type { Metadata } from "next";
import { ZendoStudy } from "../components/ZendoStudy";

export const metadata: Metadata = {
  title: "Zendo for children — English review copy",
  description: "English review copy of the children's Zendo research game.",
};

export default function EnglishChildStudyPage() {
  return <ZendoStudy variant="child" language="en" />;
}
