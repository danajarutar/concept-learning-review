"use client";

/* eslint-disable react-hooks/refs -- the monotonic checkpoint clock is read and written only by event handlers */

import { FormEvent, useEffect, useMemo, useRef, useState } from "react";
import {
  ActionEvent,
  ActiveTestRecord,
  canResumeInCurrentExperiment,
  cloneScene,
  COLOUR_LABELS,
  Colour,
  CURRENT_EXPERIMENT_VERSION,
  GENERALISATION_PROBES,
  getRule,
  INSTRUCTION_EXAMPLES,
  Language,
  MAX_SCENE_OBJECTS,
  makeTrial,
  ObjectSize,
  OPERATION_IDS,
  OPERATION_LABELS,
  OperationId,
  PRACTICE_GENERALISATION_PROBES,
  PRACTICE_INITIAL_SCENE,
  PRACTICE_RULE,
  PRACTICE_RULE_ENGLISH_TEXT,
  RULES,
  Scene,
  SceneObject,
  Shape,
  SHAPE_LABELS,
  shuffle,
  SIZE_LABELS,
  StudySession,
  TrialRecord,
  Variant,
} from "../lib/experiment";
import {
  isActionEventPayload,
  isScenePayload,
  isStudySessionPayload,
} from "../lib/checkpoint-contract";

type Phase =
  | "welcome"
  | "instructions"
  | "practiceEditor"
  | "practiceFeedback"
  | "generalisationTutorial"
  | "comprehension"
  | "ruleIntro"
  | "initial"
  | "editor"
  | "feedback"
  | "generalisation"
  | "results"
  | "demographics"
  | "complete";

type SaveState = "idle" | "saving" | "saved" | "error";

interface PersistedEnvelope {
  session: StudySession;
  phase: Phase;
  trialPosition: number;
  editorScene: Scene;
  anchorSceneId: string | null;
  sourceChoice?: "fresh" | "existing" | null;
  selectedIds?: string[];
  constructionStartedAt: string;
  actionEvents: ActionEvent[];
  hypothesis?: string;
  operations?: OperationId[];
  primaryOperation?: OperationId | "";
  otherOperation?: string;
  lastFeedback: ActiveTestRecord | null;
  finalRuleGuess?: string;
  checkpointRevision?: number;
}

const PHASES = new Set<Phase>([
  "welcome",
  "instructions",
  "practiceEditor",
  "practiceFeedback",
  "generalisationTutorial",
  "comprehension",
  "ruleIntro",
  "initial",
  "editor",
  "feedback",
  "generalisation",
  "results",
  "demographics",
  "complete",
]);

function isPersistedEnvelope(value: unknown, variant: Variant, language: Language): value is PersistedEnvelope {
  if (!value || typeof value !== "object" || Array.isArray(value)) return false;
  const envelope = value as Partial<PersistedEnvelope>;
  return (
    isStudySessionPayload(envelope.session) &&
    envelope.session.variant === variant &&
    envelope.session.language === language &&
    PHASES.has(envelope.phase as Phase) &&
    Number.isInteger(envelope.trialPosition) &&
    Number(envelope.trialPosition) >= 0 &&
    Number(envelope.trialPosition) <= 4 &&
    isScenePayload(envelope.editorScene) &&
    (envelope.anchorSceneId === null || typeof envelope.anchorSceneId === "string") &&
    (envelope.sourceChoice === undefined || envelope.sourceChoice === null ||
      envelope.sourceChoice === "fresh" || envelope.sourceChoice === "existing") &&
    typeof envelope.constructionStartedAt === "string" &&
    Number.isFinite(Date.parse(envelope.constructionStartedAt)) &&
    Array.isArray(envelope.actionEvents) &&
    envelope.actionEvents.every(isActionEventPayload) &&
    (envelope.checkpointRevision === undefined || (
      Number.isSafeInteger(envelope.checkpointRevision) && envelope.checkpointRevision >= 0
    ))
  );
}

const MAX_OBJECTS = MAX_SCENE_OBJECTS;
const COLOUR_VALUES: Colour[] = ["red", "blue", "green"];
const SIZE_VALUES: ObjectSize[] = ["small", "medium", "large"];
const SHAPE_VALUES: Shape[] = ["triangle", "square", "circle"];
const OBJECT_COLOUR_LABELS: Record<Colour, string> = {
  red: "rdeč",
  blue: "moder",
  green: "zelen",
};
const OBJECT_SIZE_LABELS: Record<ObjectSize, string> = {
  small: "majhen",
  medium: "srednji",
  large: "velik",
};
const ENGLISH_COLOUR_LABELS: Record<Colour, string> = {
  red: "red",
  blue: "blue",
  green: "green",
};
const ENGLISH_SIZE_LABELS: Record<ObjectSize, string> = {
  small: "small",
  medium: "medium",
  large: "large",
};
const ENGLISH_SHAPE_LABELS: Record<Shape, string> = {
  triangle: "triangle",
  square: "square",
  circle: "circle",
};
const ENGLISH_RULE_LABELS: Record<number, string> = {
  1: "Two shapes are the same colour.",
  2: "All shapes are the same size.",
  3: "There is a triangle and a circle in the scene.",
  4: "Exactly one shape is blue.",
  5: "There is a small green square in the scene.",
};
const ENGLISH_INSTRUCTION_RULE_LABELS: Record<string, string> = {
  "instruction-exactly-three": "There are exactly three shapes in the scene.",
  "instruction-no-red": "There are no red shapes in the scene.",
  "instruction-at-least-one-large": "There is at least one large shape in the scene.",
};
const ENGLISH_OPERATION_LABELS: Record<OperationId, string> = {
  necessity: "You changed one thing to check whether it matters.",
  sufficiency: "You removed or added shapes to find the simplest scene.",
  role_filler: "You changed one feature throughout and kept the same pattern.",
  counterexample: "You made a scene that your current rule predicts will not get a star, to check whether it gets one anyway.",
  discovery: "You started with something completely different.",
  other: "Describe what else you wanted to do …",
};
const COMPREHENSION_KEY: Record<string, boolean> = {
  star: true,
  demonstration: false,
  source: true,
  gate: true,
  batch: true,
};

const STAR_DROPS = [
  { left: 4, delay: 0.1, duration: 2.8, size: 24 },
  { left: 13, delay: 1.1, duration: 3.1, size: 34 },
  { left: 23, delay: 0.5, duration: 2.5, size: 20 },
  { left: 34, delay: 1.8, duration: 3.2, size: 29 },
  { left: 44, delay: 0.2, duration: 2.7, size: 38 },
  { left: 55, delay: 1.4, duration: 3, size: 22 },
  { left: 65, delay: 0.8, duration: 2.6, size: 31 },
  { left: 75, delay: 2, duration: 3.15, size: 19 },
  { left: 85, delay: 0.35, duration: 2.9, size: 36 },
  { left: 94, delay: 1.25, duration: 2.55, size: 25 },
  { left: 18, delay: 2.25, duration: 3.25, size: 17 },
  { left: 60, delay: 2.4, duration: 2.85, size: 27 },
];

function rotate<T>(values: readonly T[], offset: number): T[] {
  return values.map((_, index) => values[(index + offset) % values.length]);
}

function nowIso() {
  return new Date().toISOString();
}

function elapsedSince(start: string) {
  return Math.max(Date.now() - new Date(start).getTime(), 0);
}

function makeCompletionCode() {
  return `ZEN-${crypto.randomUUID().replaceAll("-", "").slice(0, 8).toUpperCase()}`;
}

function SceneView({
  scene,
  selectedIds = [],
  onObjectClick,
  compact = false,
  editable = false,
  language = "sl",
}: {
  scene: Scene;
  selectedIds?: string[];
  onObjectClick?: (objectId: string) => void;
  compact?: boolean;
  editable?: boolean;
  language?: Language;
}) {
  const objects = [...scene.objects].sort((a, b) => a.slot - b.slot);

  function renderObject(item: SceneObject) {
    const label = language === "en"
      ? `${ENGLISH_SIZE_LABELS[item.size]} ${ENGLISH_COLOUR_LABELS[item.colour]} ${ENGLISH_SHAPE_LABELS[item.shape]}`
      : `${OBJECT_SIZE_LABELS[item.size]} ${OBJECT_COLOUR_LABELS[item.colour]} ${SHAPE_LABELS[item.shape]}`;
    const selected = selectedIds.includes(item.id);
    const contents = (
      <>
        <span className={`shape-glyph shape-glyph--${item.shape}`} aria-hidden="true" />
        <span className="sr-only">{label}</span>
      </>
    );
    return onObjectClick ? (
      <button
        type="button"
        className={`scene-object scene-object--${item.shape} scene-object--${item.colour} scene-object--${item.size} ${selected ? "is-selected" : ""}`}
        key={item.id}
        aria-label={label}
        aria-pressed={selected}
        onClick={() => onObjectClick?.(item.id)}
        title={label}
      >
        {contents}
      </button>
    ) : (
      <span
        className={`scene-object scene-object--${item.shape} scene-object--${item.colour} scene-object--${item.size}`}
        key={item.id}
        role="img"
        aria-label={label}
        title={label}
      >
        {contents}
      </span>
    );
  }

  return (
    <div className={`scene-board ${compact ? "scene-board--compact" : ""} ${editable ? "scene-board--editable" : ""}`}>
      {editable ? (
        <>
          {scene.objects.length === 0 ? <div className="empty-scene-label">{language === "en" ? "Empty scene" : "Prazen prizor"}</div> : null}
          <div className="scene-slots">
            {Array.from({ length: MAX_OBJECTS }, (_, slot) => {
              const item = objects.find((candidate) => candidate.slot === slot);
              const isNext = !item && slot === objects.length;
              return (
                <div className={item ? "scene-slot scene-slot--filled" : isNext ? "scene-slot scene-slot--next" : "scene-slot"} key={slot}>
                  {item ? renderObject(item) : <span aria-hidden="true">{isNext ? "＋" : ""}</span>}
                </div>
              );
            })}
          </div>
        </>
      ) : scene.objects.length === 0 ? (
        <div className="empty-scene">{language === "en" ? "Empty scene" : "Prazen prizor"}</div>
      ) : (
        objects.map(renderObject)
      )}
    </div>
  );
}

function StarShower() {
  return (
    <div className="star-shower star-shower--positive" aria-hidden="true">
      {STAR_DROPS.map((drop, index) => (
        <span
          key={index}
          style={{
            left: `${drop.left}%`,
            top: `${8 + (index % 3) * 25}%`,
            animationDelay: `${drop.delay}s`,
            animationDuration: `${drop.duration}s`,
            fontSize: `${drop.size}px`,
          }}
        >
          ★
        </span>
      ))}
    </div>
  );
}

function ProgressHeader({
  variant,
  language,
  trialPosition,
  sceneNumber,
  saveState,
}: {
  variant: Variant;
  language: Language;
  trialPosition: number;
  sceneNumber?: number;
  saveState: SaveState;
}) {
  const saveLabel = language === "en"
    ? saveState === "saving"
      ? "Saving …"
      : saveState === "error"
        ? "Not saved · a copy is in this browser"
        : saveState === "saved"
          ? "Saved securely"
          : "Ready"
    : saveState === "saving"
      ? "Shranjevanje …"
      : saveState === "error"
        ? "Ni shranjeno · kopija je v tem brskalniku"
        : saveState === "saved"
          ? "Varno shranjeno"
          : "Pripravljeno";
  return (
    <header className="study-header">
      <div>
        <span className="eyebrow">Zendo</span>
        <strong>{language === "en" ? (variant === "adult" ? "Adult version" : "Children's version") : variant === "adult" ? "Različica za odrasle" : "Različica za otroke"}</strong>
      </div>
      <div className="study-progress" aria-label={language === "en" ? "Progress" : "Napredek"}>
        <span>{language === "en" ? "Rule" : "Pravilo"} {Math.min(trialPosition + 1, 5)} {language === "en" ? "of" : "od"} 5</span>
        {sceneNumber ? <span>{language === "en" ? "Scene" : "Prizor"} {sceneNumber} {language === "en" ? "of" : "od"} 8</span> : null}
      </div>
      <span className={`save-state save-state--${saveState}`}>{saveLabel}</span>
    </header>
  );
}

export function ZendoStudy({ variant, language = "sl" }: { variant: Variant; language?: Language }) {
  const storageKey = language === "sl" ? `zendo-study-v8-${variant}` : `zendo-study-v8-${variant}-${language}`;
  const isAdult = variant === "adult";
  const isEnglish = language === "en";
  const participantText = (adultSlovene: string, childSlovene: string, english: string) =>
    isEnglish ? english : isAdult ? adultSlovene : childSlovene;
  const colourLabels = isEnglish ? ENGLISH_COLOUR_LABELS : COLOUR_LABELS;
  const sizeLabels = isEnglish ? ENGLISH_SIZE_LABELS : SIZE_LABELS;
  const shapeLabels = isEnglish ? ENGLISH_SHAPE_LABELS : SHAPE_LABELS;
  const operationLabel = (operation: OperationId) =>
    isEnglish ? ENGLISH_OPERATION_LABELS[operation] : OPERATION_LABELS[operation][variant];
  const [phase, setPhase] = useState<Phase>("welcome");
  const [session, setSession] = useState<StudySession | null>(null);
  const [resumeCandidate, setResumeCandidate] = useState<PersistedEnvelope | null>(null);
  const [trialPosition, setTrialPosition] = useState(0);
  const [participantCode, setParticipantCode] = useState("");
  const [consent, setConsent] = useState(false);
  const [saveState, setSaveState] = useState<SaveState>("idle");
  const [notice, setNotice] = useState("");
  const [instructionPage, setInstructionPage] = useState(0);
  const [editorScene, setEditorScene] = useState<Scene>({ objects: [] });
  const [anchorSceneId, setAnchorSceneId] = useState<string | null>(null);
  const [sourceChoice, setSourceChoice] = useState<"fresh" | "existing" | null>(null);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [actionEvents, setActionEvents] = useState<ActionEvent[]>([]);
  const [constructionStartedAt, setConstructionStartedAt] = useState(nowIso());
  const [showAdd, setShowAdd] = useState(false);
  const [addMenuSequence, setAddMenuSequence] = useState(0);
  const [addColourOptions, setAddColourOptions] = useState<Colour[]>(COLOUR_VALUES);
  const [addSizeOptions, setAddSizeOptions] = useState<ObjectSize[]>(SIZE_VALUES);
  const [addShapeOptions, setAddShapeOptions] = useState<Shape[]>(SHAPE_VALUES);
  const [addColour, setAddColour] = useState<Colour>("red");
  const [addSize, setAddSize] = useState<ObjectSize>("medium");
  const [addShape, setAddShape] = useState<Shape>("triangle");
  const [hypothesis, setHypothesis] = useState("");
  const [operations, setOperations] = useState<OperationId[]>([]);
  const [primaryOperation, setPrimaryOperation] = useState<OperationId | "">("");
  const [otherOperation, setOtherOperation] = useState("");
  const [lastFeedback, setLastFeedback] = useState<ActiveTestRecord | null>(null);
  const [finalRuleGuess, setFinalRuleGuess] = useState("");
  const [comprehensionAnswers, setComprehensionAnswers] = useState<Record<string, boolean>>({});
  const [quizReviewed, setQuizReviewed] = useState(false);
  const checkpointRevisionRef = useRef(0);
  const [checkpointRevision, setCheckpointRevision] = useState(0);

  const currentTrial = session?.trials[trialPosition] ?? null;
  const currentRule = currentTrial ? getRule(currentTrial.rule_id) : null;

  useEffect(() => {
    let pendingResume: number | undefined;
    try {
      const raw = localStorage.getItem(storageKey);
      if (!raw) return;
      const parsed = JSON.parse(raw) as unknown;
      if (!isPersistedEnvelope(parsed, variant, language)) {
        localStorage.removeItem(storageKey);
        return;
      }
      if (parsed.session.status !== "complete") {
        pendingResume = window.setTimeout(() => setResumeCandidate(parsed), 0);
      }
    } catch {
      localStorage.removeItem(storageKey);
    }
    return () => {
      if (pendingResume !== undefined) window.clearTimeout(pendingResume);
    };
  }, [language, storageKey, variant]);

  useEffect(() => {
    if (!session) return;
    const envelope: PersistedEnvelope = {
      session,
      phase,
      trialPosition,
      editorScene,
      anchorSceneId,
      sourceChoice,
      selectedIds,
      constructionStartedAt,
      actionEvents,
      hypothesis,
      operations,
      primaryOperation,
      otherOperation,
      lastFeedback,
      finalRuleGuess,
      checkpointRevision,
    };
    localStorage.setItem(storageKey, JSON.stringify(envelope));
  }, [
    actionEvents,
    anchorSceneId,
    constructionStartedAt,
    checkpointRevision,
    editorScene,
    lastFeedback,
    finalRuleGuess,
    phase,
    hypothesis,
    operations,
    otherOperation,
    primaryOperation,
    selectedIds,
    session,
    storageKey,
    sourceChoice,
    trialPosition,
  ]);

  async function checkpoint(
    nextSession: StudySession,
    checkpointType: string,
    trialIndex: number | null = null,
    sceneIndex: number | null = null,
  ): Promise<{ ok: boolean; stamped: StudySession; revision: number }> {
    const clientTimestamp = nowIso();
    const stamped = { ...nextSession, last_checkpoint_at: clientTimestamp };
    const revision = checkpointRevisionRef.current + 1;
    checkpointRevisionRef.current = revision;
    setCheckpointRevision(revision);
    setSaveState("saving");
    try {
      const response = await fetch("/api/checkpoint", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          checkpoint_id: crypto.randomUUID(),
          checkpoint_type: checkpointType,
          checkpoint_revision: revision,
          trial_index: trialIndex,
          scene_index: sceneIndex,
          client_timestamp: clientTimestamp,
          session: stamped,
        }),
      });
      if (!response.ok) throw new Error("save failed");
      if (checkpointRevisionRef.current === revision) {
        setSaveState("saved");
        setSession((current) =>
          current?.session_id === stamped.session_id
            ? { ...current, last_checkpoint_at: clientTimestamp }
            : current,
        );
      }
      return { ok: true, stamped, revision };
    } catch {
      if (checkpointRevisionRef.current === revision) setSaveState("error");
      return { ok: false, stamped, revision };
    }
  }

  function newAction(event: Omit<ActionEvent, "event_id" | "timestamp" | "elapsed_ms">): ActionEvent {
    return {
      ...event,
      event_id: crypto.randomUUID(),
      timestamp: nowIso(),
      elapsed_ms: elapsedSince(constructionStartedAt),
    };
  }

  function prepareEditor(source?: { id: string; scene: Scene }) {
    const startedAt = nowIso();
    setEditorScene(source ? cloneScene(source.scene) : { objects: [] });
    setAnchorSceneId(source?.id ?? null);
    setSourceChoice(source ? "existing" : null);
    setSelectedIds([]);
    setActionEvents(source ? [
      {
        event_id: crypto.randomUUID(),
        event_type: "anchor_selected",
        timestamp: startedAt,
        elapsed_ms: 0,
        anchor_scene_id: source.id,
      },
    ] : []);
    setConstructionStartedAt(startedAt);
    setHypothesis("");
    setOperations([]);
    setPrimaryOperation("");
    setOtherOperation("");
    setShowAdd(false);
  }

  function beginEditor(_trial: TrialRecord, source?: { id: string; scene: Scene }) {
    prepareEditor(source);
    setPhase("editor");
  }

  function beginPracticeEditor(source?: { id: string; scene: Scene }) {
    prepareEditor(source);
    setPhase("practiceEditor");
  }

  function startStudy(event: FormEvent) {
    event.preventDefault();
    const code = participantCode.trim();
    if (code.length < 2 || !consent) return;
    const startedAt = nowIso();
    const newSession: StudySession = {
      schema_version: "2.2.0",
      experiment_version: CURRENT_EXPERIMENT_VERSION,
      ruleset_version: "2026-08-10-final",
      session_id: crypto.randomUUID(),
      completion_code: makeCompletionCode(),
      participant_code: code,
      variant,
      language,
      status: "instructions",
      started_at: startedAt,
      completed_at: null,
      consent_confirmed_at: startedAt,
      rule_order: shuffle(RULES.map((rule) => rule.id)),
      practice_demo: {
        rule_id: PRACTICE_RULE.id,
        rule_text: isEnglish ? PRACTICE_RULE_ENGLISH_TEXT : PRACTICE_RULE.slovene,
        started_at: null,
        active_tests: [],
        generalisation_probes: [],
        generalisation_selection_events: [],
        generalisation_started_at: null,
        generalisation_completed_at: null,
        completed_at: null,
      },
      comprehension_attempts: [],
      trials: [],
      demographics: null,
      device: {
        user_agent: navigator.userAgent,
        viewport_width: window.innerWidth,
        viewport_height: window.innerHeight,
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      },
      resume_count: 0,
      last_checkpoint_at: null,
    };
    setSession(newSession);
    setInstructionPage(0);
    setComprehensionAnswers({});
    setQuizReviewed(false);
    checkpointRevisionRef.current = 0;
    setCheckpointRevision(0);
    setNotice("");
    setPhase("instructions");
    void checkpoint(newSession, "session_started");
  }

  function resumeStudy() {
    if (!resumeCandidate || !canResumeInCurrentExperiment(resumeCandidate.session)) return;
    const restoredRevision = resumeCandidate.checkpointRevision ?? 0;
    checkpointRevisionRef.current = restoredRevision;
    setCheckpointRevision(restoredRevision);
    const restored = {
      ...resumeCandidate.session,
      resume_count: resumeCandidate.session.resume_count + 1,
    };
    setSession(restored);
    setTrialPosition(resumeCandidate.trialPosition);
    setEditorScene(resumeCandidate.editorScene);
    setAnchorSceneId(resumeCandidate.anchorSceneId);
    setSourceChoice(
      resumeCandidate.sourceChoice === undefined
        ? resumeCandidate.anchorSceneId ? "existing" : "fresh"
        : resumeCandidate.sourceChoice,
    );
    setSelectedIds(resumeCandidate.selectedIds ?? []);
    setConstructionStartedAt(resumeCandidate.constructionStartedAt);
    setActionEvents(resumeCandidate.actionEvents);
    setHypothesis(resumeCandidate.hypothesis ?? "");
    setOperations(resumeCandidate.operations ?? []);
    setPrimaryOperation(resumeCandidate.primaryOperation ?? "");
    setOtherOperation(resumeCandidate.otherOperation ?? "");
    setLastFeedback(resumeCandidate.lastFeedback ?? null);
    setFinalRuleGuess(resumeCandidate.finalRuleGuess ?? "");
    setPhase(resumeCandidate.phase);
    setResumeCandidate(null);
    void checkpoint(restored, "session_resumed", resumeCandidate.trialPosition);
  }

  function goToComprehension() {
    setNotice("");
    setPhase("comprehension");
    if (session) void checkpoint(session, "instructions_completed");
  }

  function startPracticeDemo() {
    if (!session) return;
    const next = structuredClone(session);
    next.practice_demo.started_at = nowIso();
    setSession(next);
    beginPracticeEditor();
    void checkpoint(next, "practice_demo_started");
  }

  function testPracticeScene() {
    if (!reportReady || !session || (operationPrompted && !primaryOperation)) return;
    const testedAt = nowIso();
    const record: ActiveTestRecord = {
      scene_id: crypto.randomUUID(),
      scene_index: session.practice_demo.active_tests.length + 1,
      transition_index: session.practice_demo.active_tests.length,
      anchor_scene_id: anchorSceneId,
      construction_mode: anchorSceneId ? "edit" : "fresh",
      scene: cloneScene(editorScene),
      label: PRACTICE_RULE.evaluate(editorScene),
      hypothesis_text: hypothesis.trim(),
      operation_prompted: operationPrompted,
      operations_selected: operationPrompted ? [...operations] : [],
      primary_operation: operationPrompted ? operations[0] ?? null : null,
      other_operation_text: operationPrompted && operations.includes("other") ? otherOperation.trim() : "",
      action_events: [...actionEvents],
      construction_started_at: constructionStartedAt,
      report_completed_at: testedAt,
      tested_at: testedAt,
      feedback_shown_at: nowIso(),
      construction_duration_ms: elapsedSince(constructionStartedAt),
    };
    const next = structuredClone(session);
    next.practice_demo.active_tests.push(record);
    setLastFeedback(record);
    setSession(next);
    setPhase("practiceFeedback");
    void checkpoint(next, "practice_active_test", null, record.scene_index);
  }

  function continueAfterPracticeFeedback() {
    if (!session || !lastFeedback) return;
    if (session.practice_demo.active_tests.length < 2) {
      beginPracticeEditor();
      setLastFeedback(null);
      return;
    }
    const next = structuredClone(session);
    const probes = shuffle(PRACTICE_GENERALISATION_PROBES);
    next.practice_demo.generalisation_started_at = nowIso();
    next.practice_demo.generalisation_probes = probes.map((probe, index) => ({
      probe_id: probe.id,
      scene: cloneScene(probe.scene),
      true_label: PRACTICE_RULE.evaluate(probe.scene),
      selected: false,
      display_position: index,
    }));
    setSession(next);
    setLastFeedback(null);
    setPhase("generalisationTutorial");
    void checkpoint(next, "practice_generalisation_started");
  }

  function togglePracticeProbe(probeId: string) {
    if (!session || session.practice_demo.generalisation_completed_at) return;
    const next = structuredClone(session);
    const probe = next.practice_demo.generalisation_probes.find((item) => item.probe_id === probeId);
    if (!probe) return;
    probe.selected = !probe.selected;
    next.practice_demo.generalisation_selection_events.push({
      probe_id: probeId,
      selected: probe.selected,
      timestamp: nowIso(),
      elapsed_ms: next.practice_demo.generalisation_started_at
        ? elapsedSince(next.practice_demo.generalisation_started_at)
        : 0,
    });
    setSession(next);
    void checkpoint(next, "practice_generalisation_selection");
  }

  function finishPracticeGeneralisation() {
    if (!session || !session.practice_demo.generalisation_probes.some((probe) => probe.selected)) return;
    const next = structuredClone(session);
    next.practice_demo.generalisation_completed_at = nowIso();
    next.practice_demo.completed_at = nowIso();
    setSession(next);
    void checkpoint(next, "practice_demo_completed");
  }

  function submitComprehension() {
    if (!session) return;
    if (Object.keys(comprehensionAnswers).length !== Object.keys(COMPREHENSION_KEY).length) {
      setNotice(participantText("Odgovorite na vseh pet vprašanj.", "Odgovori na vseh pet vprašanj.", "Answer all five questions."));
      return;
    }
    const correctCount = Object.entries(COMPREHENSION_KEY).filter(
      ([question, answer]) => comprehensionAnswers[question] === answer,
    ).length;
    const passed = correctCount === Object.keys(COMPREHENSION_KEY).length;
    const next = structuredClone(session);
    next.comprehension_attempts.push({
      attempt: next.comprehension_attempts.length + 1,
      answers: { ...comprehensionAnswers },
      correct_count: correctCount,
      passed,
      timestamp: nowIso(),
    });
    if (!passed) {
      setNotice(participantText(
        "Nekateri odgovori niso bili pravilni. Spodaj so označeni pravilni odgovori in kratke razlage.",
        "Nekateri odgovori niso bili pravilni. Spodaj so označeni pravilni odgovori in kratke razlage.",
        "Some answers were not correct. The correct answers and brief explanations are shown below.",
      ));
      setQuizReviewed(true);
      setSession(next);
      void checkpoint(next, "comprehension_reviewed");
      return;
    }
    beginMainTrials(next, "comprehension_passed");
  }

  function beginMainTrials(baseSession: StudySession, checkpointType: string) {
    const next = structuredClone(baseSession);
    next.status = "active";
    if (next.trials.length === 0) next.trials.push(makeTrial(next.rule_order[0], 0));
    setNotice("");
    setSession(next);
    setTrialPosition(0);
    setPhase("ruleIntro");
    void checkpoint(next, checkpointType, 0);
  }

  function showInitialDemonstration() {
    if (!session || !currentTrial) return;
    setPhase("initial");
    void checkpoint(session, "initial_positive_shown", trialPosition, 1);
  }

  function continueFromInitial() {
    if (!session || !currentTrial) return;
    void checkpoint(session, "initial_positive_viewed", trialPosition, 1);
    beginEditor(currentTrial);
  }

  const history = useMemo(() => {
    if (!currentTrial) return [];
    return [
      {
        id: currentTrial.initial_scene_id,
        label: true,
        scene: currentTrial.initial_scene,
        title: isEnglish ? "Initial positive example" : "Začetni pozitivni primer",
      },
      ...currentTrial.active_tests.map((test) => ({
        id: test.scene_id,
        label: test.label,
        scene: test.scene,
        title: `${isEnglish ? "Scene" : "Prizor"} ${test.scene_index}`,
      })),
    ];
  }, [currentTrial, isEnglish]);

  function renderEvidenceStrip(interactive = false) {
    return (
      <section className="evidence-strip" aria-label={isEnglish ? "Initial example and previous scenes" : "Začetni primer in prejšnji prizori"}>
        <div className="evidence-heading">
          <div><strong>{participantText("Začetni primer in vsi prejšnji prizori", "Začetni primer in vsi tvoji prejšnji prizori", "Initial example and all your previous scenes")}</strong><span>{isEnglish ? "They always remain visible." : "Vedno ostanejo vidni."}</span></div>
          {interactive ? <small>{participantText("Kliknite katerikoli prizor, da ga kopirate in spremenite.", "Klikni katerikoli prizor, da ga kopiraš in spremeniš.", "Click any scene to copy and change it.")}</small> : null}
        </div>
        <div className="history-list">
          {history.map((item, index) => {
            const contents = (
              <>
                <span>{item.title}</span>
                <div className="history-scene-wrap">
                  <SceneView scene={item.scene} compact language={language} />
                  <span className={item.label ? "history-result-star history-result-star--positive" : "history-result-star history-result-star--negative"} aria-label={item.label ? (isEnglish ? "Yellow stars appeared" : "Rumene zvezdice so se usule") : (isEnglish ? "No stars appeared" : "Zvezdice se niso usule")}>{item.label ? "★" : "☆"}</span>
                </div>
              </>
            );
            return interactive ? (
              <button type="button" key={item.id} onClick={() => chooseAnchor(item.id, item.scene)} className={`history-card ${index === 0 ? "history-card--initial" : ""} ${anchorSceneId === item.id ? "is-active" : ""}`}>{contents}</button>
            ) : (
              <article key={item.id} className={`history-card history-card--display ${index === 0 ? "history-card--initial" : ""}`}>{contents}</article>
            );
          })}
        </div>
      </section>
    );
  }

  function renderPracticeEvidenceStrip(interactive = true) {
    const tests = session?.practice_demo.active_tests ?? [];
    const initialContents = <>
      <span>{isEnglish ? "Initial positive example" : "Začetni pozitivni primer"}</span>
      <div className="history-scene-wrap">
        <SceneView scene={PRACTICE_INITIAL_SCENE} compact language={language} />
        <span className="history-result-star history-result-star--positive" aria-label={isEnglish ? "Yellow stars appeared" : "Rumene zvezdice so se usule"}>★</span>
      </div>
    </>;
    return (
      <section className="evidence-strip" aria-label={isEnglish ? "Initial positive example and previous demonstration scenes" : "Začetni pozitivni primer in prejšnji prikazni prizori"}>
        <div className="evidence-heading"><div><strong>{isEnglish ? "Initial positive example and previous demonstration scenes" : "Začetni pozitivni primer in prejšnji prikazni prizori"}</strong><span>{participantText("Kliknite prizor, če ga želite kopirati in spremeniti.", "Klikni prizor, če ga želiš kopirati in spremeniti.", "Click a scene if you want to copy and change it.")}</span></div></div>
        <div className="history-list">
          {interactive ? (
            <button type="button" onClick={() => chooseAnchor("practice-initial", PRACTICE_INITIAL_SCENE)} className={`history-card history-card--initial ${anchorSceneId === "practice-initial" ? "is-active" : ""}`}>{initialContents}</button>
          ) : (
            <article className="history-card history-card--display history-card--initial">{initialContents}</article>
          )}
          {tests.map((test) => {
            const contents = <>
              <span>{isEnglish ? "Demonstration scene" : "Prikazni prizor"} {test.scene_index}</span>
              <div className="history-scene-wrap">
                <SceneView scene={test.scene} compact language={language} />
                <span className={test.label ? "history-result-star history-result-star--positive" : "history-result-star history-result-star--negative"} aria-label={test.label ? (isEnglish ? "Yellow stars appeared" : "Rumene zvezdice so se usule") : (isEnglish ? "No stars appeared" : "Zvezdice se niso usule")}>{test.label ? "★" : "☆"}</span>
              </div>
            </>;
            return interactive ? (
              <button type="button" key={test.scene_id} onClick={() => chooseAnchor(test.scene_id, test.scene)} className={`history-card ${anchorSceneId === test.scene_id ? "is-active" : ""}`}>{contents}</button>
            ) : (
              <article key={test.scene_id} className="history-card history-card--display">{contents}</article>
            );
          })}
        </div>
      </section>
    );
  }

  function chooseAnchor(id: string, source: Scene) {
    setEditorScene(cloneScene(source));
    setAnchorSceneId(id);
    setSourceChoice("existing");
    setSelectedIds([]);
    setActionEvents((events) => [
      ...events,
      newAction({ event_type: "anchor_selected", anchor_scene_id: id }),
    ]);
  }

  function startFresh() {
    setEditorScene({ objects: [] });
    setAnchorSceneId(null);
    setSourceChoice("fresh");
    setSelectedIds([]);
    setActionEvents((events) => [
      ...events,
      newAction({ event_type: "fresh_started", anchor_scene_id: null }),
    ]);
    setShowAdd(false);
  }

  function requestExistingSource() {
    setSourceChoice("existing");
    setAnchorSceneId(null);
    setSelectedIds([]);
    setShowAdd(false);
  }

  function toggleAddPanel() {
    if (showAdd) {
      setShowAdd(false);
      return;
    }
    const nextSequence = (addMenuSequence + 1) % 3;
    const colours = rotate(COLOUR_VALUES, nextSequence);
    const sizes = rotate(SIZE_VALUES, (nextSequence + 1) % 3);
    const shapes = rotate(SHAPE_VALUES, (nextSequence + 2) % 3);
    setAddMenuSequence(nextSequence);
    setAddColourOptions(colours);
    setAddSizeOptions(sizes);
    setAddShapeOptions(shapes);
    setAddColour(colours[0]);
    setAddSize(sizes[0]);
    setAddShape(shapes[0]);
    setShowAdd(true);
  }

  function toggleObject(objectId: string) {
    setSelectedIds((selected) => {
      const next = selected.includes(objectId)
        ? selected.filter((id) => id !== objectId)
        : [...selected, objectId];
      setActionEvents((events) => [
        ...events,
        newAction({
          event_type: "selection_changed",
          object_ids: [objectId],
          before: selected,
          after: next,
        }),
      ]);
      return next;
    });
  }

  function addObject() {
    if (editorScene.objects.length >= MAX_OBJECTS) return;
    const item: SceneObject = {
      id: crypto.randomUUID(),
      colour: addColour,
      size: addSize,
      shape: addShape,
      slot: editorScene.objects.length,
    };
    setEditorScene((current) => ({ objects: [...current.objects, item] }));
    setSelectedIds([item.id]);
    setActionEvents((events) => [
      ...events,
      newAction({ event_type: "object_added", object_ids: [item.id], after: item }),
    ]);
    setShowAdd(false);
  }

  function removeSelected() {
    if (selectedIds.length === 0) return;
    const removed = editorScene.objects.filter((item) => selectedIds.includes(item.id));
    const remaining = editorScene.objects
      .filter((item) => !selectedIds.includes(item.id))
      .map((item, index) => ({ ...item, slot: index }));
    setEditorScene({ objects: remaining });
    setActionEvents((events) => [
      ...events,
      newAction({
        event_type: "objects_removed",
        object_ids: selectedIds,
        before: removed,
      }),
    ]);
    setSelectedIds([]);
  }

  function changeFeature(
    feature: "colour" | "size" | "shape",
    value: Colour | ObjectSize | Shape,
  ) {
    if (selectedIds.length === 0) return;
    const before = editorScene.objects
      .filter((item) => selectedIds.includes(item.id))
      .map((item) => ({ id: item.id, value: item[feature] }));
    const objects = editorScene.objects.map((item) =>
      selectedIds.includes(item.id) ? { ...item, [feature]: value } : item,
    );
    setEditorScene({ objects });
    setActionEvents((events) => [
      ...events,
      newAction({
        event_type: "feature_changed",
        object_ids: [...selectedIds],
        feature,
        before,
        after: selectedIds.map((id) => ({ id, value })),
      }),
    ]);
  }

  function toggleOperation(operation: OperationId) {
    setOperations((current) => {
      const next = current.includes(operation)
        ? current.filter((item) => item !== operation)
        : [...current, operation];
      setPrimaryOperation(next[0] ?? "");
      if (!next.includes("other")) setOtherOperation("");
      return next;
    });
  }

  const practiceEditorMode = phase === "practiceEditor";
  const operationPrompted = practiceEditorMode || phase === "editor";
  const reportReady =
    editorScene.objects.length > 0 &&
    (sourceChoice === "fresh" || anchorSceneId !== null) &&
    hypothesis.trim().length >= 3 &&
    (!operationPrompted || (
      operations.length >= 1 &&
      primaryOperation === operations[0] &&
      (!operations.includes("other") || otherOperation.trim().length >= 3)
    ));

  function testScene() {
    if (!reportReady || !session || !currentTrial || !currentRule || (operationPrompted && !primaryOperation)) return;
    const testedAt = nowIso();
    const record: ActiveTestRecord = {
      scene_id: crypto.randomUUID(),
      scene_index: currentTrial.active_tests.length + 2,
      transition_index: currentTrial.active_tests.length,
      anchor_scene_id: anchorSceneId,
      construction_mode: anchorSceneId ? "edit" : "fresh",
      scene: cloneScene(editorScene),
      label: currentRule.evaluate(editorScene),
      hypothesis_text: hypothesis.trim(),
      operation_prompted: operationPrompted,
      operations_selected: operationPrompted ? [...operations] : [],
      primary_operation: operationPrompted ? operations[0] ?? null : null,
      other_operation_text: operationPrompted && operations.includes("other") ? otherOperation.trim() : "",
      action_events: [...actionEvents],
      construction_started_at: constructionStartedAt,
      report_completed_at: testedAt,
      tested_at: testedAt,
      feedback_shown_at: nowIso(),
      construction_duration_ms: elapsedSince(constructionStartedAt),
    };
    const next = structuredClone(session);
    next.trials[trialPosition].active_tests.push(record);
    if (next.trials[trialPosition].active_tests.length >= 7) setFinalRuleGuess("");
    setLastFeedback(record);
    setSession(next);
    setPhase("feedback");
    void checkpoint(next, "active_test", trialPosition, record.scene_index);
  }

  function continueAfterFeedback() {
    if (!session || !currentTrial || !lastFeedback) return;
    const latestTrial = session.trials[trialPosition];
    if (latestTrial.active_tests.length >= 7) {
      if (finalRuleGuess.trim().length < 3) return;
      const next = structuredClone(session);
      const trial = next.trials[trialPosition];
      trial.final_rule_guess = finalRuleGuess.trim();
      trial.final_rule_guess_at = nowIso();
      const probes = shuffle(GENERALISATION_PROBES[trial.rule_id]);
      trial.generalisation_started_at = nowIso();
      trial.generalisation_probes = probes.map((probe, index) => ({
        probe_id: probe.id,
        scene: cloneScene(probe.scene),
        true_label: getRule(trial.rule_id).evaluate(probe.scene),
        selected: false,
        display_position: index,
      }));
      setSession(next);
      setPhase("generalisation");
      void checkpoint(next, "generalisation_started", trialPosition);
      return;
    }
    beginEditor(latestTrial);
    setLastFeedback(null);
  }

  function toggleProbe(probeId: string) {
    if (!session) return;
    const next = structuredClone(session);
    const trial = next.trials[trialPosition];
    const probe = trial.generalisation_probes.find((item) => item.probe_id === probeId);
    if (!probe) return;
    probe.selected = !probe.selected;
    trial.generalisation_selection_events.push({
      probe_id: probeId,
      selected: probe.selected,
      timestamp: nowIso(),
      elapsed_ms: trial.generalisation_started_at
        ? elapsedSince(trial.generalisation_started_at)
        : 0,
    });
    setSession(next);
    void checkpoint(next, "generalisation_selection", trialPosition);
  }

  function submitGeneralisation() {
    if (!session || !currentTrial) return;
    const next = structuredClone(session);
    const trial = next.trials[trialPosition];
    trial.generalisation_completed_at = nowIso();
    trial.ended_at = nowIso();
    const isLast = trialPosition === next.rule_order.length - 1;
    if (isLast) {
      next.status = "debrief";
      setSession(next);
      setPhase("results");
      void checkpoint(next, "trial_completed", trialPosition);
      return;
    }
    const nextPosition = trialPosition + 1;
    next.trials.push(makeTrial(next.rule_order[nextPosition], nextPosition));
    setSession(next);
    setTrialPosition(nextPosition);
    setPhase("ruleIntro");
    void checkpoint(next, "trial_completed", trialPosition);
  }

  async function submitDemographics(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!session) return;
    const data = new FormData(event.currentTarget);
    const ageYears = Number(data.get("age_years"));
    const ageMonths = Number(data.get("age_months"));
    const engagement = Number(data.get("engagement"));
    const difficulty = Number(data.get("difficulty"));
    const gender = String(data.get("gender") ?? "");
    if (!ageYears || ageMonths < 0 || ageMonths > 11 || !engagement || !difficulty || !gender) {
      setNotice(participantText("Izpolnite vsa obvezna polja.", "Izpolni vsa obvezna polja.", "Complete all required fields."));
      return;
    }
    const next = structuredClone(session);
    next.demographics = {
      age_years: ageYears,
      age_months: ageMonths,
      gender,
      engagement,
      difficulty,
      feedback: String(data.get("feedback") ?? "").trim(),
      submitted_at: nowIso(),
    };
    const completed = structuredClone(next);
    completed.status = "complete";
    completed.completed_at = nowIso();
    setNotice("");
    setSession(next);
    const result = await checkpoint(completed, "session_completed", trialPosition);
    if (!result.ok) {
      setNotice(participantText(
        "Končno shranjevanje ni uspelo. Podatki ostajajo v tem brskalniku; preverite povezavo in poskusite znova.",
        "Končno shranjevanje ni uspelo. Podatki ostajajo v tem brskalniku; preveri povezavo in poskusi znova.",
        "The final save failed. The data remain in this browser; check the connection and try again.",
      ));
      return;
    }
    setSession(result.stamped);
    setPhase("complete");
  }

  function renderWelcome() {
    return (
      <main className="welcome-shell">
        <section className="welcome-card">
          <img className="university-logo" src="/university-of-primorska-logo.png" alt={isEnglish ? "University of Primorska" : "Univerza na Primorskem"} />
          <h1>{participantText("Ali ste pripravljeni, da začnete nalogo?", "Ali si pripravljen(a), da začneš nalogo?", "Are you ready to begin the task?")}</h1>
          {resumeCandidate && canResumeInCurrentExperiment(resumeCandidate.session) ? (
            <div className="resume-card">
              <strong>{isEnglish ? "An unfinished session is safely stored in this browser." : "Nedokončana seja je varno shranjena v tem brskalniku."}</strong>
              <button className="button button--secondary" type="button" onClick={resumeStudy}>
                {participantText("Nadaljujte shranjeno sejo", "Nadaljuj shranjeno sejo", "Continue saved session")}
              </button>
            </div>
          ) : null}
          {resumeCandidate && !canResumeInCurrentExperiment(resumeCandidate.session) ? (
            <div className="resume-card" role="status">
              <strong>{isEnglish ? "The previous unfinished session cannot be continued because the response options have changed." : "Prejšnje nedokončane seje ni mogoče nadaljevati, ker so se možnosti odgovorov spremenile."}</strong>
              <p>{participantText("Začnite novo sejo z novo šifro udeleženca; že shranjeni podatki bodo ostali v raziskovalnem izvozu.", "Začni novo sejo z novo šifro udeleženca; že shranjeni podatki bodo ostali pri raziskovalcu(ki).", "Start a new session with a new participant code; the data already saved will remain with the researcher.")}</p>
            </div>
          ) : null}
          <form onSubmit={startStudy} className="stack-form">
            <label>
              {isEnglish ? "Participant code" : "Šifra udeleženca"}
              <input
                value={participantCode}
                onChange={(event) => setParticipantCode(event.target.value)}
                autoComplete="off"
                maxLength={60}
                required
              />
            </label>
            <label className="check-row">
              <input type="checkbox" checked={consent} onChange={(event) => setConsent(event.target.checked)} />
              <span>
                {isEnglish ? "I want to start the game and understand that I can stop playing at any time if I do not feel comfortable." : "Želim začeti igro in razumem, da jo lahko kadarkoli preneham igrati, če se ne počutim dobro."}
              </span>
            </label>
            <button className="button button--primary" disabled={!consent || participantCode.trim().length < 2}>
              {participantText("Preberite navodila", "Poglej navodila", "View the instructions")}
            </button>
          </form>
        </section>
      </main>
    );
  }

  function renderInstructions() {
    return (
      <main className="content-shell">
        <section className="paper-card instructions-card">
          <div className="instruction-progress" aria-label={isEnglish ? "Instruction progress" : "Napredek skozi navodila"}>
            {[0, 1, 2].map((index) => <span className={index === instructionPage ? "is-active" : index < instructionPage ? "is-done" : ""} key={index}>{index + 1}</span>)}
          </div>
          {notice ? <p className="form-notice">{notice}</p> : null}
          {instructionPage === 0 ? (
            <>
              <p className="eyebrow">{isEnglish ? "Instructions" : "Navodila"}</p>
              <h1>{participantText("Dobrodošli v igri s planeta Zendo", "Dobrodošel(a) v igri s planeta Zendo", "Welcome to the game from planet Zendo")}</h1>
              <p className="lead">{participantText("Hvala, da ste se odločili igrati mojo igro! V tej igri se boste učili o tujem planetu, ki se imenuje Zendo. Na planetu Zendo živijo posebni liki, glejte spodaj.", "Hvala, da si se odločil(a) igrati mojo igro! V tej igri se boš učil(a) o tujem planetu, ki se imenuje Zendo. Na planetu Zendo živijo posebni liki, glej spodaj.", "Thank you for choosing to play my game! In this game, you will learn about an alien planet called Zendo. Special shapes live on planet Zendo, as shown below.")}</p>
              <img className="zendo-intro-image" src="/zendo-shapes-intro.png" alt={isEnglish ? "A red triangle, blue square and green circle among astronauts on planet Zendo" : "Rdeč trikotnik, moder kvadrat in zelen krog med astronavti na planetu Zendo"} width="1536" height="1024" />
              <p className="instruction-copy">{isEnglish ? "The shapes differ in colour, size and form, and they appear together in scenes. But be careful: some scenes cause yellow stars to shower down. Scenes that cause a shower of stars follow a hidden rule. If a scene does not follow the rule, the stars do not appear. The stars therefore provide feedback about the whole scene; they are not a property of an individual shape." : "Liki se razlikujejo po barvi, velikosti in obliki ter se pojavljajo skupaj v prizorih. Ampak pozor: nekateri prizori povzročijo vsip rumenih zvezdic. Prizori, ki povzročijo vsip zvezdic, sledijo skritemu pravilu. Če prizor pravilu ne ustreza, se zvezdice ne usujejo. Zvezdice so torej povratna informacija o celotnem prizoru, ne lastnost posameznega lika."}</p>
              <p className="instruction-copy">{isEnglish ? "The hidden rule may concern colour, size, shape, number of shapes, or a combination of these features. The instructions for these scenes have been lost in the star laboratory. You will be a young researcher and use tests to help rediscover how they work." : <>Skrito pravilo je lahko povezano z barvo, velikostjo, obliko, številom likov ali kombinacijo teh lastnosti. V zvezdnem laboratoriju so izgubili navodila za te prizore. {isAdult ? "Vi boste raziskovalec(ka) in boste s preizkusi pomagali ponovno odkriti, kako delujejo." : "Ti boš mladi(a) raziskovalec(ka) in boš s preizkusi pomagal(a) ponovno odkriti, kako delujejo."}</>}</p>
              <img className="zendo-intro-image zendo-lab-image" src="/zendo-lab-two-platforms.png" alt={isEnglish ? "Two young astronauts test scenes: yellow stars appear over the scene on the left, while no stars appear over the scene on the right" : "Dva mlada astronavta preizkušata prizora: pri levem se usujejo rumene zvezdice, pri desnem se zvezdice ne usujejo"} width="1536" height="1024" />
            </>
          ) : null}

          {instructionPage === 1 ? (
            <>
              <p className="eyebrow">{isEnglish ? "Instructions" : "Navodila"}</p>
              <p className="lead-small">{participantText("Pravila za delovanje nekaterih skupin likov smo že odkrili. Poglejmo, kako delujejo tri skupine. Zapomnite si: vsaka skupina deluje po svojem pravilu.", "Pravila za delovanje nekaterih skupin likov smo že odkrili. Poglejmo, kako delujejo tri skupine. Zapomni si: vsaka skupina deluje po svojem pravilu.", "We have already discovered the rules followed by some groups of shapes. Let us look at how three groups work. Remember: each group follows its own rule.")}</p>
              <div className="worked-rules">
                {INSTRUCTION_EXAMPLES.map((example) => (
                  <article key={example.id}>
                    <h2><strong>{isEnglish ? "Rule:" : "Pravilo:"}</strong> {isEnglish ? ENGLISH_INSTRUCTION_RULE_LABELS[example.id] : example.slovene}</h2>
                    <p>{isEnglish ? "Stars shower down when the scene follows this rule." : "Zvezdice se usujejo, če je prizor v skladu s tem pravilom."}</p>
                    <div className="worked-scenes">
                      {example.positiveScenes.map((exampleScene, index) => <div key={`${example.id}-positive-${index}`}><span className="star-key star-key--positive">★</span><SceneView scene={exampleScene} compact language={language} /></div>)}
                      {example.negativeScenes.map((exampleScene, index) => <div key={`${example.id}-negative-${index}`}><span className="star-key star-key--negative">☆</span><SceneView scene={exampleScene} compact language={language} /></div>)}
                    </div>
                  </article>
                ))}
              </div>
              <p className="instruction-copy instruction-summary">{isEnglish ? "So there are many ways for scenes made from the special shapes to summon stars! Scenes with different numbers of shapes, colours, sizes, forms and many other features can summon stars." : "Torej obstaja veliko načinov, kako lahko iz posebnih blokov prikličeš zvezdice! Zvezdice lahko prikličejo prizori z različnim številom likov, različnimi barvami, različnimi velikostmi, različnimi oblikami in še marsičim."}</p>
            </>
          ) : null}

          {instructionPage === 2 ? (
            <>
              <p className="eyebrow">{isEnglish ? "Instructions" : "Navodila"}</p>
              <h1>{participantText("Vaša raziskovalna naloga", "Tvoja raziskovalna naloga", "Your research task")}</h1>
              <div className="research-task-copy">
                <p>{participantText("Na planetu Zorb so odkrili, da obstaja še pet skritih pravil. Vi boste raziskovalec(ka) in boste s preizkusi pomagali ponovno odkriti pet različnih pravil, zaradi katerih prizori prikličejo zvezdice.", "Na planetu Zorb so odkrili, da obstaja še pet skritih pravil! Ti boš mladi(a) raziskovalec(ka) in boš s preizkusi pomagal(a) ponovno odkriti pet različnih pravil, zaradi katerih prizori prikličejo zvezdice.", "On planet Zorb, five more hidden rules have been discovered! You will be a young researcher and use tests to help rediscover the five different rules that make scenes summon stars.")}</p>
                <ol>
                  <li>{isEnglish ? <><strong>construct scenes</strong>: you will add and remove shapes and change their colour, size and form;</> : isAdult ? <><strong>sestavljali prizore</strong>: dodajali in odstranjevali boste like ter jim spreminjali barvo, velikost in obliko;</> : <><strong>sestavljal(a) prizore</strong>: dodajal(a) in odstranjeval(a) boš like ter jim spreminjal(a) barvo, velikost in obliko;</>}</li>
                  <li>{isEnglish ? <>write down what you think the <strong>hidden rule</strong> is;</> : isAdult ? <>zapisali boste, kaj mislite, da je <strong>skrito pravilo</strong>;</> : <>zapisal(a) boš, kaj misliš, da je <strong>skrito pravilo</strong>;</>}</li>
                  <li>{isEnglish ? <><strong>choose an operation description</strong> that best describes what you did; you can choose more than one description. You will then test the scene and find out whether it follows the rule.</> : isAdult ? <><strong>izbrali boste opis operacije</strong>, ki najbolje pove, kaj ste naredili; izberete lahko več opisov. Nato boste prizor preizkusili in izvedeli, ali sledi pravilu.</> : <><strong>izbral(a) boš opis operacije</strong>, ki najbolje pove, kaj si naredil(a); izbereš lahko več opisov. Nato boš prizor preizkusil(a) in izvedel(a), ali sledi pravilu.</>}</li>
                </ol>
                <p>{participantText("Pred začetkom vam bo raziskovalec(ka) na dveh prizorih pokazal(a), kako sestavite prizor, zapišete pravilo in izberete operacijo.", "Pred začetkom ti bo raziskovalec(ka) na dveh prizorih pokazal(a), kako sestaviš prizor, zapišeš pravilo in izbereš operacijo.", "Before you begin, the researcher will use two scenes to show you how to construct a scene, write down a rule and choose an operation.")}</p>
              </div>
            </>
          ) : null}

          <div className="instruction-actions">
            {instructionPage > 0 ? <button className="button button--secondary" type="button" onClick={() => setInstructionPage((value) => value - 1)}>{isEnglish ? "Back" : "Nazaj"}</button> : <span />}
            {instructionPage < 2 ? (
              <button className="button button--primary" type="button" onClick={() => { setNotice(""); setInstructionPage((value) => value + 1); }}>{participantText("Naprej", "Nadaljuj", "Continue")}</button>
            ) : (
              <button className="button button--primary" type="button" onClick={startPracticeDemo}>{participantText("Začnite prikaz", "Začni prikaz", "Start the demonstration")}</button>
            )}
          </div>
        </section>
      </main>
    );
  }

  function renderPracticeFeedback() {
    if (!lastFeedback || !session) return null;
    return (
      <main className="study-shell feedback-shell">
        <header className="study-header demo-study-header"><div><span className="eyebrow">{isEnglish ? "Demonstration scene result" : "Rezultat prikaznega prizora"}</span><strong>{isEnglish ? "Two-scene demonstration" : "Prikaz dveh prizorov"}</strong></div><div className="study-progress"><span>{isEnglish ? "Demonstration scene" : "Prikazni prizor"} {lastFeedback.scene_index} {isEnglish ? "of" : "od"} 2</span></div><span className={`save-state save-state--${saveState}`}>{saveState === "saved" ? (isEnglish ? "Saved securely" : "Varno shranjeno") : (isEnglish ? "Demonstration" : "Prikaz")}</span></header>
        {renderPracticeEvidenceStrip(false)}
        <section className="editor-layout feedback-editor-layout">
          <div className="paper-card board-card">
            <div className="section-heading"><div><p className="eyebrow">{isEnglish ? "Tested scene" : "Preizkušeni prizor"}</p><h1>{isEnglish ? "The scene stays in place" : "Prizor ostane na mestu"}</h1></div><span>{lastFeedback.scene.objects.length}/{MAX_OBJECTS} {isEnglish ? "shapes" : "likov"}</span></div>
            <p className="placement-note">{isEnglish ? "The result is added directly to the constructed scene." : "Rezultat je dodan neposredno na sestavljeni prizor."}</p>
            <div className="feedback-board-wrap">
              <SceneView scene={lastFeedback.scene} editable language={language} />
              {lastFeedback.label ? <StarShower /> : null}
              <span className={lastFeedback.label ? "scene-result-star scene-result-star--positive" : "scene-result-star scene-result-star--negative"} aria-label={lastFeedback.label ? (isEnglish ? "Yellow stars appeared" : "Rumene zvezdice so se usule") : (isEnglish ? "No stars appeared" : "Zvezdice se niso usule")}>{lastFeedback.label ? "★" : "☆"}</span>
            </div>
          </div>
          <aside className="paper-card controls-card result-panel">
            <p className="eyebrow">{isEnglish ? "Result" : "Rezultat"}</p>
            <h2>{lastFeedback.label ? (isEnglish ? "Yellow stars appeared" : "Rumene zvezdice so se usule") : (isEnglish ? "No stars appeared" : "Zvezdice se niso usule")}</h2>
            <p>{lastFeedback.label ? (isEnglish ? "This scene follows the demonstration rule." : "Ta prizor sledi prikaznemu pravilu.") : (isEnglish ? "This scene does not follow the demonstration rule, so no stars appeared." : "Ta prizor ne sledi prikaznemu pravilu, zato se zvezdice niso usule.")}</p>
            {lastFeedback.primary_operation ? <div className="demo-explanation"><strong>{isEnglish ? "Selected operation:" : "Izbrana operacija:"}</strong> {operationLabel(lastFeedback.primary_operation)}</div> : null}
            <button className="button button--primary" type="button" onClick={continueAfterPracticeFeedback}>{session.practice_demo.active_tests.length < 2 ? participantText("Sestavite drugi prikazni prizor", "Sestavi drugi prikazni prizor", "Construct the second demonstration scene") : participantText("Pokažite izbiro novih prizorov", "Pokaži izbiro novih prizorov", "Show the new-scene selection")}</button>
          </aside>
        </section>
      </main>
    );
  }

  function renderGeneralisationTutorial() {
    if (!session) return null;
    const demo = session.practice_demo;
    const revealed = Boolean(demo.generalisation_completed_at);
    const anySelected = demo.generalisation_probes.some((probe) => probe.selected);
    const correct = demo.generalisation_probes.every((probe) => probe.selected === probe.true_label);
    return (
      <main className="content-shell">
        <section className="paper-card generalisation-card">
          <p className="eyebrow">{isEnglish ? "Instructions · new scenes" : "Navodila · novi prizori"}</p>
          <h1>{participantText("Kako izberete prizore, ki sledijo pravilu", "Kako izbereš prizore, ki prikličejo zvezdo", "How to choose the scenes that summon a star")}</h1>
          <p className="lead-small">{participantText("Po sedmih preizkusih boste videli osem novih prizorov. Izberite vse, za katere menite, da sledijo istemu pravilu. Pravilen odgovor je lahko več prizorov; položaj kartic ni namig.", "Po sedmih preizkusih boš videl(a) osem novih prizorov. Izberi vse, za katere misliš, da sledijo istemu pravilu. Pravilen odgovor je lahko več prizorov; položaj kartic ni namig.", "After seven tests, you will see eight new scenes. Select every scene that you think follows the same rule. More than one scene may be correct; the positions of the cards are not a clue.")}</p>
          <div className="probe-grid">
            {demo.generalisation_probes.map((probe) => (
              <button type="button" key={probe.probe_id} disabled={revealed} className={`${probe.selected ? "probe-card is-selected" : "probe-card"} ${revealed && probe.true_label ? "is-correct" : ""} ${revealed && probe.selected !== probe.true_label ? "is-incorrect" : ""}`} onClick={() => togglePracticeProbe(probe.probe_id)} aria-pressed={probe.selected}>
                <span className="probe-check">{probe.selected ? "✓" : ""}</span>
                <SceneView scene={probe.scene} compact language={language} />
                {revealed ? <small>{probe.true_label ? (isEnglish ? "★ stars appear" : "★ zvezdice se usujejo") : (isEnglish ? "☆ stars do not appear" : "☆ zvezdice se ne usujejo")}</small> : null}
              </button>
            ))}
          </div>
          {!revealed ? <button className="button button--primary" type="button" disabled={!anySelected} onClick={finishPracticeGeneralisation}>{participantText("Preverite prikazno izbiro", "Preveri prikazno izbiro", "Check the demonstration selection")}</button> : <div className={correct ? "result-banner result-banner--positive" : "result-banner result-banner--negative"}><span>{correct ? "★" : "☆"}</span><div><strong>{correct ? (isEnglish ? "All scenes were selected correctly." : "Vsi prizori so pravilno izbrani.") : (isEnglish ? "The correct labels are shown." : "Prikazane so pravilne oznake.")}</strong><p>{isEnglish ? "In the main game, you will not receive feedback about these new scenes. After you confirm your choices, the next rule or the final questions will begin." : "V glavni igri povratne informacije o teh novih prizorih ne bo. Po potrditvi se bo začelo naslednje pravilo oziroma zaključna vprašanja."}</p></div></div>}
          {revealed ? <button className="button button--primary" type="button" onClick={goToComprehension}>{participantText("Preverite razumevanje", "Preveri, ali razumeš", "Check your understanding")}</button> : null}
        </section>
      </main>
    );
  }

  const comprehensionQuestions = isEnglish ? [
    { id: "star", adult: "Do yellow stars mean that a scene follows the hidden rule?", child: "Do yellow stars mean that a scene follows the hidden rule?", adultExplanation: "When yellow stars appear, the scene follows the hidden rule. If they do not appear, it does not follow the rule.", childExplanation: "When yellow stars appear, the scene follows the hidden rule. If they do not appear, it does not follow the rule." },
    { id: "demonstration", adult: "Do all groups of shapes follow the same rule?", child: "Do all groups of shapes follow the same rule?", adultExplanation: "No. Each group of shapes follows its own rule.", childExplanation: "No. Each group of shapes follows its own rule." },
    { id: "source", adult: "Can you start with a new empty scene or choose any previous scene?", child: "Can you start with a new empty scene or choose any previous scene?", adultExplanation: "For every test, you can choose a fresh empty scene or a copy of any previous scene.", childExplanation: "For every test, you can choose a fresh empty scene or a copy of any previous scene." },
    { id: "gate", adult: "From the first test onwards, must you choose an operation description before testing?", child: "From the first test onwards, must you choose an operation description before testing?", adultExplanation: "Yes. Before every test, including the first, you must choose at least one operation description.", childExplanation: "Yes. Before every test, including the first, you must choose at least one operation description." },
    { id: "batch", adult: "Can you select several shapes and change the same feature for all of them at once?", child: "Can you select several shapes and change the same feature for all of them at once?", adultExplanation: "You can select several shapes and then change their colour, size or form at the same time.", childExplanation: "You can select several shapes and then change their colour, size or form at the same time." },
  ] : [
    { id: "star", adult: "Ali rumene zvezdice pomenijo, da prizor sledi skritemu pravilu?", child: "Ali rumene zvezdice pomenijo, da prizor sledi skritemu pravilu?", adultExplanation: "Ko se usujejo rumene zvezdice, prizor sledi skritemu pravilu. Če se ne usujejo, mu ne sledi.", childExplanation: "Ko se usujejo rumene zvezdice, prizor sledi skritemu pravilu. Če se ne usujejo, mu ne sledi." },
    { id: "demonstration", adult: "Ali vse skupine likov sledijo istemu pravilu?", child: "Ali vse skupine likov sledijo istemu pravilu?", adultExplanation: "Ne. Vsaka skupina likov sledi svojemu pravilu.", childExplanation: "Ne. Vsaka skupina likov sledi svojemu pravilu." },
    { id: "source", adult: "Ali lahko začnete z novim praznim prizorom ali izberete katerikoli stari prizor?", child: "Ali lahko začneš z novim praznim prizorom ali izbereš katerikoli stari prizor?", adultExplanation: "Pri vsakem preizkusu lahko izberete svež prazen prizor ali kopijo kateregakoli prejšnjega prizora.", childExplanation: "Pri vsakem preizkusu lahko izbereš svež prazen prizor ali kopijo kateregakoli prejšnjega prizora." },
    { id: "gate", adult: "Ali morate od prvega preizkusa naprej pred testiranjem izbrati opis operacije?", child: "Ali moraš od prvega preizkusa naprej pred testiranjem izbrati opis operacije?", adultExplanation: "Da. Pred vsakim preizkusom, tudi prvim, izberete najmanj en opis operacije.", childExplanation: "Da. Pred vsakim preizkusom, tudi prvim, izbereš najmanj en opis operacije." },
    { id: "batch", adult: "Ali lahko označite več likov in jim hkrati spremenite isto lastnost?", child: "Ali lahko označiš več likov in jim hkrati spremeniš isto lastnost?", adultExplanation: "Izberete lahko več likov in nato vsem hkrati spremenite barvo, velikost ali obliko.", childExplanation: "Izbereš lahko več likov in nato vsem hkrati spremeniš barvo, velikost ali obliko." },
  ];

  function renderComprehension() {
    return (
      <main className="content-shell">
        <section className="paper-card quiz-card">
          <p className="eyebrow">{isEnglish ? "Understanding check" : "Preverjanje razumevanja"}</p>
          <h1>{participantText("Pred začetkom odgovorite na pet vprašanj", "Pred začetkom odgovori na pet vprašanj", "Answer five questions before you begin")}</h1>
          <p className="lead-small">{participantText("Odgovorite na vsa vprašanja. Če se zmotite, boste takoj videli pravilen odgovor in kratko razlago.", "Odgovori na vsa vprašanja. Če se zmotiš, boš takoj videl(a) pravilen odgovor in kratko razlago.", "Answer every question. If you make a mistake, you will immediately see the correct answer and a brief explanation.")}</p>
          {comprehensionQuestions.map((question, index) => (
            <fieldset key={question.id} className={quizReviewed && comprehensionAnswers[question.id] !== COMPREHENSION_KEY[question.id] ? "quiz-question quiz-question--incorrect" : "quiz-question"}>
              <legend>{index + 1}. {question[variant]}</legend>
              <div className="segmented">
                {[true, false].map((answer) => (
                  <button
                    key={String(answer)}
                    type="button"
                    className={comprehensionAnswers[question.id] === answer ? "is-active" : ""}
                    disabled={quizReviewed}
                    onClick={() => setComprehensionAnswers((current) => ({ ...current, [question.id]: answer }))}
                  >
                    {answer ? (isEnglish ? "Yes" : "Da") : (isEnglish ? "No" : "Ne")}
                  </button>
                ))}
              </div>
              {quizReviewed && comprehensionAnswers[question.id] !== COMPREHENSION_KEY[question.id] ? (
                <p className="quiz-correction"><strong>{isEnglish ? "Correct answer:" : "Pravilen odgovor:"} {COMPREHENSION_KEY[question.id] ? (isEnglish ? "Yes" : "Da") : (isEnglish ? "No" : "Ne")}.</strong> {isAdult ? question.adultExplanation : question.childExplanation}</p>
              ) : null}
            </fieldset>
          ))}
          {notice ? <p className="form-notice">{notice}</p> : null}
          <button className="button button--primary" type="button" onClick={quizReviewed && session ? () => beginMainTrials(session, "comprehension_feedback_acknowledged") : submitComprehension}>{quizReviewed ? participantText("Nadaljujte v igro", "Nadaljuj v igro", "Continue to the game") : participantText("Preverite odgovore", "Preveri odgovore", "Check answers")}</button>
        </section>
      </main>
    );
  }

  function renderRuleIntro() {
    return (
      <main className="content-shell rule-intro-shell">
        <section className="paper-card rule-intro-card">
          <div className="rule-number">{trialPosition + 1}</div>
          <p className="eyebrow">{trialPosition === 0 ? (isEnglish ? "The first task begins" : "Začenja se prva naloga") : (isEnglish ? "New hidden rule" : "Novo skrito pravilo")}</p>
          <h1>{isEnglish ? "Rule" : "Pravilo"} {trialPosition + 1} {isEnglish ? "of" : "od"} 5</h1>
          <p className="lead">
            {isEnglish
              ? trialPosition === 0
                ? "The star laboratory is opening its first station. First look at a positive scene that summons a star, and then you will begin constructing scenes."
                : "You have arrived at a new star station. A completely new rule applies here, so you no longer need the previous one. First, simply observe the initial example."
              : isAdult
              ? trialPosition === 0
                ? "Zvezdni laboratorij odpira prvo postajo. Najprej si oglejte pozitiven prizor, ki prikliče zvezdo, nato pa boste začeli sestavljati prizore."
                : "Prejšnja naloga je končana. Zdaj se začenja povsem novo, neodvisno pravilo. Najprej samo opazujte njegov začetni primer."
              : trialPosition === 0
                ? "Zvezdni laboratorij odpira prvo postajo. Najprej poglej pozitiven prizor, ki prikliče zvezdo, nato pa boš ti začel(a) sestavljati prizore."
                : "Prispel(a) si na novo zvezdno postajo. Tukaj velja povsem novo pravilo, zato prejšnjega ne potrebuješ več. Najprej samo opazuj začetni primer."}
          </p>
          {variant === "child" ? <div className="story-box"><span aria-hidden="true">★</span><p>{isEnglish ? "Every test helps the laboratory restore part of the lost star instructions." : "Vsak preizkus pomaga laboratoriju obnoviti del izgubljenih zvezdnih navodil."}</p></div> : null}
          <button className="button button--primary" type="button" onClick={showInitialDemonstration}>{participantText("Pokažite začetni primer", "Pokaži začetni primer", "Show the initial example")}</button>
        </section>
      </main>
    );
  }

  function renderInitial() {
    if (!currentTrial) return null;
    return (
      <main className="study-shell">
        <ProgressHeader variant={variant} language={language} trialPosition={trialPosition} sceneNumber={1} saveState={saveState} />
        <section className="paper-card initial-card">
          <p className="eyebrow">{participantText("Začetni pozitivni primer · samo opazujte", "Začetni pozitivni primer · samo opazuj", "Initial positive example · just observe")}</p>
          <h1>{isEnglish ? "This scene follows the hidden rule" : "Ta prizor sledi skritemu pravilu"}</h1>
          <p className="lead-small">{participantText("To je prvi namig za novo pravilo. Prizora ne spreminjajte in ga ne testirajte.", "To je prvi namig za novo pravilo. Prizora ne spreminjaj in ga ne preizkušaj.", "This is the first clue to the new rule. Do not change or test the scene.")}</p>
          <SceneView scene={currentTrial.initial_scene} language={language} />
          <div className="result-banner result-banner--positive"><span>★</span><div><strong>{isEnglish ? "Yellow stars appeared." : "Rumene zvezdice so se usule."}</strong><p>{isEnglish ? "This scene follows the hidden rule." : "Ta prizor sledi skritemu pravilu."}</p></div></div>
          <button className="button button--primary" type="button" onClick={continueFromInitial}>{participantText("Nadaljujte na sestavljanje prizora", "Nadaljuj na sestavljanje prizora", "Continue to scene construction")}</button>
        </section>
      </main>
    );
  }

  function renderEditor() {
    const practiceMode = phase === "practiceEditor";
    if (!practiceMode && !currentTrial) return null;
    const sceneNumber = practiceMode
      ? (session?.practice_demo.active_tests.length ?? 0) + 1
      : (currentTrial?.active_tests.length ?? 0) + 2;
    const sourceReady = sourceChoice === "fresh" || (sourceChoice === "existing" && anchorSceneId !== null);
    return (
      <main className="study-shell">
        {practiceMode ? (
          <header className="study-header demo-study-header"><div><span className="eyebrow">{isEnglish ? "Construction demonstration" : "Prikaz sestavljanja"}</span><strong>{isEnglish ? "Two-scene demonstration" : "Prikaz dveh prizorov"}</strong></div><div className="study-progress"><span>{isEnglish ? "Demonstration scene" : "Prikazni prizor"} {sceneNumber} {isEnglish ? "of" : "od"} 2</span></div><span className={`save-state save-state--${saveState}`}>{saveState === "saved" ? (isEnglish ? "Saved securely" : "Varno shranjeno") : (isEnglish ? "Demonstration" : "Prikaz")}</span></header>
        ) : <ProgressHeader variant={variant} language={language} trialPosition={trialPosition} sceneNumber={sceneNumber} saveState={saveState} />}
        <section className="source-choice-panel" aria-label={isEnglish ? "Choose the starting point for the new test" : "Izbira osnove za novi preizkus"}>
          <div className="source-choice-heading">
            <h1>{participantText("Kako želite začeti ta prizor?", "Kako želiš začeti ta prizor?", "How do you want to start this scene?")}</h1>
          </div>
          <div className="source-choice-grid">
            <button type="button" className={sourceChoice === "fresh" ? "source-choice-card is-active" : "source-choice-card"} onClick={startFresh}>
              <span className="source-choice-icon" aria-hidden="true">＋</span>
              <strong>{isEnglish ? "New empty scene" : "Nov prazen prizor"}</strong>
              <small>{participantText("Začnite brez likov in sestavite nov prizor.", "Začni brez likov in sestavi nov prizor.", "Start without any shapes and construct a new scene.")}</small>
            </button>
            <button type="button" className={sourceChoice === "existing" ? "source-choice-card is-active" : "source-choice-card"} onClick={requestExistingSource}>
              <span className="source-choice-icon" aria-hidden="true">▣</span>
              <strong>{participantText("Izberite obstoječi prizor", "Izberi obstoječi prizor", "Choose an existing scene")}</strong>
              <small>{participantText("Spodaj kliknite prizor, ki ga želite kopirati in spremeniti.", "Spodaj klikni prizor, ki ga želiš kopirati in spremeniti.", "Click the scene below that you want to copy and change.")}</small>
            </button>
          </div>
          {sourceChoice === "existing" && !anchorSceneId ? <p className="source-choice-prompt">↓ {participantText("Zdaj izberite enega od prizorov neposredno spodaj.", "Zdaj izberi enega od prizorov neposredno spodaj.", "Now choose one of the scenes directly below.")}</p> : null}
        </section>
        {practiceMode ? renderPracticeEvidenceStrip() : renderEvidenceStrip(true)}

        {sourceReady ? <>
        <section className="editor-layout">
          <div className="paper-card board-card">
            <div className="section-heading"><div><p className="eyebrow">{practiceMode ? (isEnglish ? "Demonstration test" : "Prikazni preizkus") : participantText("Vaš novi preizkus", "Tvoj novi preizkus", "Your new test")}</p><h1>{anchorSceneId ? participantText("Spremenite izbrani prizor", "Spremeni izbrani prizor", "Change the selected scene") : participantText("Sestavite prizor", "Sestavi prizor", "Construct a scene")}</h1></div><span>{editorScene.objects.length}/{MAX_OBJECTS} {isEnglish ? "shapes" : "likov"}</span></div>
            <p className="placement-note">{isEnglish ? "Position is not part of the rules. Every added shape is automatically placed in the next available position." : "Položaj ni del pravil. Vsak dodani lik se samodejno postavi na naslednje prosto mesto."}</p>
            <SceneView scene={editorScene} selectedIds={selectedIds} onObjectClick={toggleObject} editable language={language} />
            <div className="board-actions">
              <button type="button" className="button button--secondary" onClick={toggleAddPanel} disabled={editorScene.objects.length >= MAX_OBJECTS}>＋ {participantText("Dodajte lik", "Dodaj lik", "Add a shape")}</button>
              <button type="button" className="button button--danger" onClick={removeSelected} disabled={selectedIds.length === 0}>{participantText("Odstranite izbrane", "Odstrani izbrane", "Remove selected")}</button>
            </div>
            {showAdd ? (
              <div className="add-panel">
                <label>{isEnglish ? "Colour" : "Barva"}<select value={addColour} onChange={(event) => setAddColour(event.target.value as Colour)}>{addColourOptions.map((value) => <option value={value} key={value}>{colourLabels[value]}</option>)}</select></label>
                <label>{isEnglish ? "Size" : "Velikost"}<select value={addSize} onChange={(event) => setAddSize(event.target.value as ObjectSize)}>{addSizeOptions.map((value) => <option value={value} key={value}>{sizeLabels[value]}</option>)}</select></label>
                <label>{isEnglish ? "Shape" : "Oblika"}<select value={addShape} onChange={(event) => setAddShape(event.target.value as Shape)}>{addShapeOptions.map((value) => <option value={value} key={value}>{shapeLabels[value]}</option>)}</select></label>
                <button type="button" className="button button--primary" onClick={addObject}>{participantText("Dodajte", "Dodaj", "Add")}</button>
              </div>
            ) : null}
          </div>

          <aside className="paper-card controls-card">
            <p className="eyebrow">{isEnglish ? "Selected shapes" : "Izbrani liki"}</p>
            <h2>{selectedIds.length ? `${isEnglish ? "Selected" : "Izbrano"}: ${selectedIds.length}` : participantText("Kliknite lik za urejanje", "Klikni lik za urejanje", "Click a shape to edit it")}</h2>
            <p className="muted">{participantText("Kliknite en lik ali zaporedoma več likov. Modra obroba pokaže, kateri liki so označeni.", "Klikni en lik ali zaporedoma več likov. Modra obroba pokaže, kateri liki so označeni.", "Click one shape, or several shapes in succession. A blue outline shows which shapes are selected.")}</p>
            <ControlButtons label={isEnglish ? "Colour" : "Barva"} values={colourLabels} selectedObjects={editorScene.objects.filter((item) => selectedIds.includes(item.id))} feature="colour" disabled={!selectedIds.length} onChange={(value) => changeFeature("colour", value as Colour)} />
            <ControlButtons label={isEnglish ? "Size" : "Velikost"} values={sizeLabels} selectedObjects={editorScene.objects.filter((item) => selectedIds.includes(item.id))} feature="size" disabled={!selectedIds.length} onChange={(value) => changeFeature("size", value as ObjectSize)} />
            <ControlButtons label={isEnglish ? "Shape" : "Oblika"} values={shapeLabels} selectedObjects={editorScene.objects.filter((item) => selectedIds.includes(item.id))} feature="shape" disabled={!selectedIds.length} onChange={(value) => changeFeature("shape", value as Shape)} />
          </aside>
        </section>

        <section className="paper-card report-card">
          <label className="hypothesis-field">
            {isEnglish ? "What do you think the rule is?" : "Kaj misliš, da je pravilo?"}
            <textarea value={hypothesis} onChange={(event) => setHypothesis(event.target.value)} rows={3} placeholder={isEnglish ? "My current rule is …" : "Moje trenutno pravilo je …"} />
          </label>
          {operationPrompted ? (
            <>
              <fieldset className="operations-fieldset">
                <legend>{participantText("Kaj najbolje opisuje, kaj ste pravkar naredili? Izberete lahko več opisov.", "Kaj najbolje opisuje, kaj si pravkar naredil(a)? Izbereš lahko več opisov.", "What best describes what you just did? You can choose more than one description.")}</legend>
                <div className="operation-grid">
                  {OPERATION_IDS.map((operation) => (
                    <label key={operation} className={operations.includes(operation) ? "operation-choice is-active" : "operation-choice"}>
                      <input type="checkbox" checked={operations.includes(operation)} onChange={() => toggleOperation(operation)} />
                      <span>{operationLabel(operation)}</span>
                    </label>
                  ))}
                </div>
              </fieldset>
              {operations.includes("other") ? (
                <textarea className="other-operation-input" aria-label={operationLabel("other")} placeholder={operationLabel("other")} rows={2} value={otherOperation} onChange={(event) => setOtherOperation(event.target.value)} />
              ) : null}
            </>
          ) : null}
          {sourceChoice === null ? <p className="form-notice">{participantText("Pred nadaljevanjem zgoraj izberite nov prazen prizor ali obstoječi prizor.", "Pred nadaljevanjem zgoraj izberi nov prazen prizor ali obstoječi prizor.", "Before continuing, choose a new empty scene or an existing scene above.")}</p> : null}
          {editorScene.objects.length === 0 ? <p className="form-notice">{participantText("Pred testiranjem dodajte vsaj en lik.", "Pred preizkusom dodaj vsaj en lik.", "Add at least one shape before testing.")}</p> : null}
          {reportReady ? <button type="button" className="button button--test" onClick={practiceMode ? testPracticeScene : testScene}>▷ {participantText("Testirajte prizor", "Preizkusi prizor", "Test the scene")}</button> : <p className="test-gate">{practiceMode ? (isEnglish ? "The test button appears when the scene is ready and the required response has been completed." : "Gumb za testiranje se pokaže, ko je prizor pripravljen in je zahtevani odgovor izpolnjen.") : (isEnglish ? "The test button appears when the scene is ready and the required responses have been completed." : "Gumb za testiranje se pokaže, ko je prizor pripravljen in so zahtevani odgovori izpolnjeni.")}</p>}
        </section>
        </> : (
          <section className="paper-card source-waiting-card" aria-live="polite">
            <span className="source-choice-icon" aria-hidden="true">↑</span>
            <div>
              <h2>{participantText("Najprej izberite, kako želite začeti.", "Najprej izberi, kako želiš začeti.", "First choose how you want to begin.")}</h2>
              <p>{sourceChoice === "existing"
                ? participantText("Zgoraj ste izbrali obstoječi prizor. Zdaj kliknite prizor v vrstici primerov, da ga kopirate in uredite.", "Zgoraj si izbral(a) obstoječi prizor. Zdaj klikni prizor v vrstici primerov, da ga kopiraš in urediš.", "You chose an existing scene above. Now click a scene in the row of examples to copy and edit it.")
                : participantText("Izberite nov prazen prizor ali obstoječi prizor. Orodja za sestavljanje se bodo nato prikazala spodaj.", "Izberi nov prazen prizor ali obstoječi prizor. Orodja za sestavljanje se bodo nato prikazala spodaj.", "Choose a new empty scene or an existing scene. The construction tools will then appear below.")}</p>
            </div>
          </section>
        )}
      </main>
    );
  }

  function renderFeedback() {
    if (!lastFeedback) return null;
    const isFinalActiveScene = (currentTrial?.active_tests.length ?? 0) >= 7;
    const finalGuessReady = !isFinalActiveScene || finalRuleGuess.trim().length >= 3;
    return (
      <main className="study-shell feedback-shell">
        <ProgressHeader variant={variant} language={language} trialPosition={trialPosition} sceneNumber={lastFeedback.scene_index} saveState={saveState} />
        {renderEvidenceStrip()}
        <section className="editor-layout feedback-editor-layout">
          <div className="paper-card board-card">
            <div className="section-heading"><div><p className="eyebrow">{isEnglish ? "Tested scene" : "Preizkušeni prizor"}</p><h1>{participantText("Vaš prizor in rezultat", "Tvoj prizor in rezultat", "Your scene and result")}</h1></div><span>{lastFeedback.scene.objects.length}/{MAX_OBJECTS} {isEnglish ? "shapes" : "likov"}</span></div>
            <p className="placement-note">{participantText("Prizor ostane takšen, kot ste ga sestavili; doda se samo povratna informacija o zvezdicah.", "Prizor ostane takšen, kot si ga sestavil(a); doda se samo povratna informacija o zvezdicah.", "The scene remains exactly as you constructed it; only the star feedback is added.")}</p>
            <div className="feedback-board-wrap">
              <SceneView scene={lastFeedback.scene} editable language={language} />
              {lastFeedback.label ? <StarShower /> : null}
              <span className={lastFeedback.label ? "scene-result-star scene-result-star--positive" : "scene-result-star scene-result-star--negative"} aria-label={lastFeedback.label ? (isEnglish ? "Yellow stars appeared" : "Rumene zvezdice so se usule") : (isEnglish ? "No stars appeared" : "Zvezdice se niso usule")}>{lastFeedback.label ? "★" : "☆"}</span>
            </div>
          </div>
          <aside className="paper-card controls-card result-panel">
            <p className="eyebrow">{isEnglish ? "Result" : "Rezultat"}</p>
            <h2>{lastFeedback.label ? (isEnglish ? "Yellow stars appeared" : "Rumene zvezdice so se usule") : (isEnglish ? "No stars appeared" : "Zvezdice se niso usule")}</h2>
            <p>{lastFeedback.label ? (isEnglish ? "This scene follows the hidden rule." : "Ta prizor sledi skritemu pravilu.") : (isEnglish ? "This scene does not follow the hidden rule, so no stars appeared." : "Ta prizor ne sledi skritemu pravilu, zato se zvezdice niso usule.")}</p>
            {isFinalActiveScene ? (
              <label className="hypothesis-field final-hypothesis-field">
                {isEnglish ? "What do you think the rule is?" : "Kaj misliš, da je pravilo?"}
                <textarea value={finalRuleGuess} onChange={(event) => setFinalRuleGuess(event.target.value)} rows={3} placeholder={isEnglish ? "My current rule is …" : "Moje trenutno pravilo je …"} />
              </label>
            ) : null}
            <button className="button button--primary" type="button" onClick={continueAfterFeedback} disabled={!finalGuessReady}>{participantText("Nadaljujte", "Nadaljuj", "Continue")}</button>
          </aside>
        </section>
      </main>
    );
  }

  function renderGeneralisation() {
    if (!currentTrial) return null;
    return (
      <main className="study-shell">
        <ProgressHeader variant={variant} language={language} trialPosition={trialPosition} saveState={saveState} />
        {renderEvidenceStrip()}
        <section className="paper-card generalisation-card">
          <p className="eyebrow">{isEnglish ? "New scenes" : "Novi prizori"}</p>
          <h1>{participantText("Kateri prizori sledijo istemu pravilu?", "Kateri prizori prikličejo zvezdo?", "Which scenes summon a star?")}</h1>
          <p className="lead-small">{participantText("Izberite vse prizore, za katere menite, da sledijo skritemu pravilu. Če menite, da ne sledi noben, ne izberite nobenega.", "Izberi vse prizore, za katere misliš, da sledijo skritemu pravilu. Če misliš, da ne sledi noben, ne izberi nobenega.", "Select every scene that you think follows the hidden rule. If you think none of them follow it, do not select any.")}</p>
          <div className="probe-grid">
            {currentTrial.generalisation_probes.map((probe) => (
              <button type="button" key={probe.probe_id} className={probe.selected ? "probe-card is-selected" : "probe-card"} onClick={() => toggleProbe(probe.probe_id)} aria-pressed={probe.selected}>
                <span className="probe-check">{probe.selected ? "✓" : ""}</span>
                <SceneView scene={probe.scene} compact language={language} />
              </button>
            ))}
          </div>
          <button className="button button--primary" type="button" onClick={submitGeneralisation}>{participantText("Potrdite izbiro", "Potrdi izbiro", "Confirm selection")}</button>
        </section>
      </main>
    );
  }

  function renderResults() {
    const trialResults = (session?.trials ?? []).map((trial) => ({
      trial,
      rule: getRule(trial.rule_id),
      correct: trial.generalisation_probes.filter((probe) => probe.selected === probe.true_label).length,
    }));
    const total = trialResults.reduce((sum, result) => sum + result.correct, 0);
    const maximum = trialResults.length * 8;
    return (
      <main className="content-shell">
        <section className="paper-card results-card">
          <p className="eyebrow">{isEnglish ? "Game results" : "Rezultati igre"}</p>
          <h1>{isEnglish ? `You scored ${total} out of ${maximum} points in total.` : isAdult ? `Skupaj ste dosegli ${total} od ${maximum} točk.` : `Skupaj si dosegel(a) ${total} od ${maximum} točk.`}</h1>
          <p className="lead-small">{participantText("Spodaj so prikazana pravila, vaša uspešnost pri novih prizorih in vaše zadnje ugibanje pri vsakem pravilu.", "Spodaj vidiš pravila, svoj rezultat pri novih prizorih in svoje zadnje ugibanje pri vsakem pravilu.", "Below you can see the rules, your score for the new scenes and your final guess for each rule.")}</p>
          <ol className="results-list">
            {trialResults.map(({ trial, rule, correct }) => (
              <li key={trial.trial_id}>
                <div className="result-score"><strong>{correct}</strong><span>{isEnglish ? "of 8" : "od 8"}</span></div>
                <div>
                  <p><strong>{isEnglish ? "The rule was:" : "Pravilo je bilo:"}</strong> {isEnglish ? ENGLISH_RULE_LABELS[rule.id] : rule.slovene}</p>
                  <p>{isEnglish ? `You correctly classified ${correct} of the 8 test scenes.` : isAdult ? `Pravilno ste ocenili ${correct} od 8 testnih prizorov.` : `Pravilno si ocenil(a) ${correct} od 8 testnih prizorov.`}</p>
                  <p className="result-guess"><strong>{participantText("Vaše ugibanje pravila je bilo:", "Tvoje ugibanje pravila je bilo:", "Your rule guess was:")}</strong> {trial.final_rule_guess || (isEnglish ? "I don't know." : "Ne vem.")}</p>
                </div>
              </li>
            ))}
          </ol>
          <button className="button button--primary" type="button" onClick={() => setPhase("demographics")}>{participantText("Nadaljujte na zaključna vprašanja", "Nadaljuj na zaključna vprašanja", "Continue to the final questions")}</button>
        </section>
      </main>
    );
  }

  function renderDemographics() {
    return (
      <main className="content-shell">
        <section className="paper-card demographics-card">
          <p className="eyebrow">{isEnglish ? "A few more questions" : "Še nekaj vprašanj"}</p><h1>{isEnglish ? "Thank you for completing the game" : "Hvala za opravljeno igro"}</h1>
          <form onSubmit={submitDemographics} className="stack-form">
            <div className="form-row"><label>{isEnglish ? "Age in years" : "Starost v letih"}<input name="age_years" type="number" min="5" max="100" defaultValue={session?.demographics?.age_years} required /></label><label>{isEnglish ? "Additional months" : "Dodatni meseci"}<input name="age_months" type="number" min="0" max="11" defaultValue={session?.demographics?.age_months ?? 0} required /></label></div>
            <label>{isEnglish ? "Gender" : "Spol"}<select name="gender" required defaultValue={session?.demographics?.gender ?? ""}><option value="" disabled>{isEnglish ? "Select" : "Izberite"}</option><option value="female">{isEnglish ? "female" : "ženska"}</option><option value="male">{isEnglish ? "male" : "moški"}</option><option value="nonbinary">{isEnglish ? "non-binary" : "nebinarno"}</option><option value="self_describe">{isEnglish ? "other / self-describe" : "drugo / samoopis"}</option><option value="prefer_not">{isEnglish ? "prefer not to answer" : "ne želim odgovoriti"}</option></select></label>
            <label>{isEnglish ? "How interesting was the game?" : "Kako zanimiva je bila igra?"} <span className="range-labels"><span>1 — {isEnglish ? "not at all" : "sploh ne"}</span><span>7 — {isEnglish ? "very" : "zelo"}</span></span><input name="engagement" type="range" min="1" max="7" defaultValue={session?.demographics?.engagement ?? 4} /></label>
            <label>{isEnglish ? "How difficult was the game?" : "Kako težka je bila igra?"} <span className="range-labels"><span>1 — {isEnglish ? "very easy" : "zelo lahka"}</span><span>7 — {isEnglish ? "very difficult" : "zelo težka"}</span></span><input name="difficulty" type="range" min="1" max="7" defaultValue={session?.demographics?.difficulty ?? 4} /></label>
            <label>{participantText("Ali nam želite še kaj sporočiti?", "Ali nam želiš še kaj sporočiti?", "Is there anything else you would like to tell us?")}<textarea name="feedback" rows={4} defaultValue={session?.demographics?.feedback ?? ""} /></label>
            {notice ? <p className="form-notice">{notice}</p> : null}
            <button className="button button--primary" disabled={saveState === "saving"}>{saveState === "saving" ? (isEnglish ? "Saving …" : "Shranjujem …") : participantText("Končajte in shranite", "Končaj in shrani", "Finish and save")}</button>
          </form>
        </section>
      </main>
    );
  }

  function renderComplete() {
    return (
      <main className="welcome-shell">
        <section className="welcome-card completion-card">
          <div className="brand-mark">★</div><p className="eyebrow">{isEnglish ? "Successfully completed" : "Uspešno zaključeno"}</p><h1>{isEnglish ? "Thank you very much!" : "Najlepša hvala!"}</h1>
          <p className="lead">{isEnglish ? "All responses have been sent and saved securely." : "Vsi odgovori so bili poslani in varno shranjeni."}</p>
          <div className="completion-code"><span>{isEnglish ? "Completion code" : "Zaključna šifra"}</span><strong>{session?.completion_code}</strong></div>
          <p className="muted">{isEnglish ? "You can now close this page." : "To stran lahko zdaj zaprete."}</p>
        </section>
      </main>
    );
  }

  if (phase === "welcome") return renderWelcome();
  if (phase === "instructions") return renderInstructions();
  if (phase === "practiceEditor") return renderEditor();
  if (phase === "practiceFeedback") return renderPracticeFeedback();
  if (phase === "generalisationTutorial") return renderGeneralisationTutorial();
  if (phase === "comprehension") return renderComprehension();
  if (phase === "ruleIntro") return renderRuleIntro();
  if (phase === "initial") return renderInitial();
  if (phase === "editor") return renderEditor();
  if (phase === "feedback") return renderFeedback();
  if (phase === "generalisation") return renderGeneralisation();
  if (phase === "results") return renderResults();
  if (phase === "demographics") return renderDemographics();
  return renderComplete();
}

function ControlButtons({
  label,
  values,
  selectedObjects,
  feature,
  disabled,
  onChange,
}: {
  label: string;
  values: Record<string, string>;
  selectedObjects: SceneObject[];
  feature: "colour" | "size" | "shape";
  disabled: boolean;
  onChange: (value: string) => void;
}) {
  return (
    <div className="control-group">
      <span>{label}</span>
      <div>
        {Object.entries(values).map(([value, text]) => (
          <button
            type="button"
            key={value}
            className={selectedObjects.length > 0 && selectedObjects.every((item) => item[feature] === value) ? "is-current" : ""}
            aria-pressed={selectedObjects.length > 0 && selectedObjects.every((item) => item[feature] === value)}
            onClick={() => onChange(value)}
            disabled={disabled}
          >
            {text}
          </button>
        ))}
      </div>
    </div>
  );
}
