import type { Metadata } from "next";
import { ZendoStudy } from "../components/ZendoStudy";

export const metadata: Metadata = {
  title: "Zendo za otroke",
  description: "Otroška različica raziskovalne igre Zendo v slovenščini.",
};

export default function ChildStudyPage() {
  return <ZendoStudy variant="child" />;
}
