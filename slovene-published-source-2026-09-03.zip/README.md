# Zendo concept-learning experiment

This repository contains the Slovene adult and child Zendo task, its Cloudflare
D1 checkpoint/export boundary, and separate modelling workspaces. The hosted
task is a vinext/React application; it is not the original starter template.

## Runtime and checks

- Node.js `>=22.13.0`
- `npm run dev` starts the local application.
- `npm test` builds the worker and runs the rendered/application contract tests.
- `npm run lint` and `npx tsc --noEmit` check source quality and types.
- `npm run db:generate` generates migrations after a deliberate schema change.

The application declares the D1 binding `DB` in `.openai/hosting.json`.
Checkpoint persistence cannot work without that binding and the committed
Drizzle migrations. Applying migrations to a real database is an explicit
deployment operation; generating a migration does not apply it.

## Study and data contract

The current experiment version is `zendo-simplified-1.9.1` with export schema
`2.2.0`. Version 1.9.1 revises participant-facing consent and instruction copy
and expands the worked rules to two positive and one negative example each.
Version 1.9.0 limits constructed scenes to five objects, permits more
than one operation report from the first construction onward, adds a positive
practice anchor, and shows generalisation scores before demographics. Version
1.8.0 retains its exactly-one-operation contract; version 1.7.0 introduced the
explicit `counterexample` report between `role_filler` and `discovery`.
Historical `zendo-simplified-1.6.2` records retain their five-value vocabulary
and must not contain `counterexample`.

The browser saves a lossless JSON session at monotonically increasing positive
checkpoint revisions. Immutable session identity, status progression, frozen
rules/scenes, chronological indices, and operation vocabulary are validated at
the API boundary. Local storage is a recoverable client copy, not evidence of a
successful server save. The completion page is shown only after the final
`session_completed` checkpoint succeeds.

The authenticated `/izvoz` page reconstructs a stable keyset-paginated snapshot
from immutable checkpoint history and downloads it as NDJSON (one session object
per line). The endpoint requires the
server-side `EXPORT_KEY`; it intentionally exports incomplete and completed
sessions so interrupted-session QC remains possible. Empirical analysis loaders
must use strict completed-session mode unless a tool is explicitly labelled as
incomplete QC.

## Migrations relevant to existing databases

- `0000_organic_shen.sql` creates the original study tables.
- `0001_concerned_kat_farrell.sql` adds checkpoint revisions.
- `0002_perfect_azazel.sql` makes every positive `(session_id,
  checkpoint_revision)` pair unique while leaving migrated historical revision
  zero rows intact.
- `0003_new_whistler.sql` adds the legacy timestamp/UUID export-supporting
  index.
- `0004_perfect_lady_vermin.sql` backfills and introduces the database-assigned
  checkpoint sequence used as the race-free point-in-time export boundary.

Before deployment, apply these migrations to a staging D1 database and verify a
new session, interrupted resume, conflicting concurrent revision, final save,
and multi-page export. This repository does not claim those external deployment
checks have been performed.

## Modelling safety status

The corrected-v3 modelling directory has its own README and fail-closed audit,
timing, provenance, and checkpoint contracts. Committed approvals and timing
artifacts are hash-bound snapshots, not blanket authorization after source or
configuration changes. The empirical arbitrary-scene observation universe gate
remains intentionally closed; do not treat a dry run or the prototype scorer as
authorization for empirical inference.

Corrected-v3 completed checkpoint rows use authenticated schema
`zendo-analysis-checkpoint-2`: the deterministic cell seed, canonical JSON
bytes, and per-row SHA-256 are verified on resume and export. Earlier
unauthenticated SQLite checkpoints are deliberately rejected and require a new
database path; they are not silently upgraded into trusted evidence.
