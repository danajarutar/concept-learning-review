declare module "cloudflare:workers" {
  export const env: {
    DB: D1Database;
    EXPORT_KEY?: string;
  };
}

interface Fetcher {
  fetch(request: Request): Promise<Response>;
}

type D1Database = {
  prepare(query: string): unknown;
  batch(statements: unknown[]): Promise<unknown[]>;
};
