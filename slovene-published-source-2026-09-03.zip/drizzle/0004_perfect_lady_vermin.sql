CREATE TABLE `study_checkpoint_exports` (
	`sequence` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`checkpoint_id` text NOT NULL,
	FOREIGN KEY (`checkpoint_id`) REFERENCES `study_checkpoints`(`checkpoint_id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `study_checkpoint_exports_checkpoint_id_unique` ON `study_checkpoint_exports` (`checkpoint_id`);
--> statement-breakpoint
INSERT INTO `study_checkpoint_exports` (`checkpoint_id`)
SELECT `checkpoint_id`
FROM `study_checkpoints`
ORDER BY `created_at`, `checkpoint_id`;
