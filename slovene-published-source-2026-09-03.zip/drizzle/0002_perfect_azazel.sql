CREATE UNIQUE INDEX `uq_study_checkpoints_session_revision` ON `study_checkpoints` (`session_id`,`checkpoint_revision`) WHERE "study_checkpoints"."checkpoint_revision" > 0;--> statement-breakpoint
PRAGMA optimize;
