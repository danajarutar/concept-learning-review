ALTER TABLE `study_checkpoints` ADD `checkpoint_revision` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `study_sessions` ADD `last_checkpoint_revision` integer DEFAULT 0 NOT NULL;
