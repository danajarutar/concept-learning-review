CREATE INDEX `idx_study_checkpoints_created_id` ON `study_checkpoints` (`created_at`,`checkpoint_id`);--> statement-breakpoint
PRAGMA optimize;
