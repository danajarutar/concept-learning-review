CREATE TABLE `study_checkpoints` (
	`checkpoint_id` text PRIMARY KEY NOT NULL,
	`session_id` text NOT NULL,
	`checkpoint_type` text NOT NULL,
	`trial_index` integer,
	`scene_index` integer,
	`client_timestamp` text NOT NULL,
	`payload_json` text NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	FOREIGN KEY (`session_id`) REFERENCES `study_sessions`(`session_id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `idx_study_checkpoints_session_created` ON `study_checkpoints` (`session_id`,`created_at`);--> statement-breakpoint
CREATE TABLE `study_sessions` (
	`session_id` text PRIMARY KEY NOT NULL,
	`participant_code` text NOT NULL,
	`variant` text NOT NULL,
	`schema_version` text NOT NULL,
	`experiment_version` text NOT NULL,
	`ruleset_version` text NOT NULL,
	`status` text NOT NULL,
	`current_trial` integer DEFAULT 0 NOT NULL,
	`payload_json` text NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	`updated_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	`completed_at` text
);
--> statement-breakpoint
CREATE INDEX `idx_study_sessions_variant_status` ON `study_sessions` (`variant`,`status`);--> statement-breakpoint
CREATE INDEX `idx_study_sessions_updated_at` ON `study_sessions` (`updated_at`);