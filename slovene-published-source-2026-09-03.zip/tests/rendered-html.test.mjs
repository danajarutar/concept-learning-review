import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";
import {
  canResumeInCurrentExperiment,
  CURRENT_EXPERIMENT_VERSION,
  INSTRUCTION_EXAMPLES,
  OPERATION_IDS,
  OPERATION_LABELS,
  PRACTICE_INITIAL_SCENE,
  PRACTICE_RULE,
  PRACTICE_RULE_ENGLISH_TEXT,
  validateMaterials,
} from "../app/lib/experiment.ts";
import {
  parseStudySessionPayload,
  serializeStudySessionPayload,
} from "../app/lib/session-payload.ts";
import {
  immutableSessionIdentity,
  isStudySessionPayload,
  validateCheckpointRequest,
  validateSessionProgression,
} from "../app/lib/checkpoint-contract.ts";

function validInstructionSession(overrides = {}) {
  const timestamp = "2026-08-17T10:00:00.000Z";
  return {
    schema_version: "2.2.0",
    experiment_version: CURRENT_EXPERIMENT_VERSION,
    ruleset_version: "2026-08-10-final",
    session_id: "11111111-1111-4111-8111-111111111111",
    completion_code: "ZEN-12AB34CD",
    participant_code: "AUDIT-001",
    variant: "adult",
    language: "sl",
    status: "instructions",
    started_at: timestamp,
    completed_at: null,
    consent_confirmed_at: timestamp,
    rule_order: [1, 2, 3, 4, 5],
    practice_demo: {
      rule_id: "practice-exactly-two",
      rule_text: "V prizoru sta natanko dva lika.",
      started_at: null,
      active_tests: [],
      generalisation_probes: [],
      generalisation_selection_events: [],
      generalisation_started_at: null,
      generalisation_completed_at: null,
      completed_at: null,
    },
    comprehension_attempts: [],
    trials: [],
    demographics: null,
    device: {
      user_agent: "audit",
      viewport_width: 1280,
      viewport_height: 720,
      timezone: "Europe/Berlin",
    },
    resume_count: 0,
    last_checkpoint_at: timestamp,
    ...overrides,
  };
}

function validCheckpoint(session = validInstructionSession()) {
  return {
    checkpoint_id: "22222222-2222-4222-8222-222222222222",
    checkpoint_type: "session_started",
    checkpoint_revision: 1,
    trial_index: null,
    scene_index: null,
    client_timestamp: "2026-08-17T10:00:00.000Z",
    session,
  };
}

async function render(pathname = "/") {
  const workerUrl = new URL("../dist/server/index.js", import.meta.url);
  workerUrl.searchParams.set("test", `${process.pid}-${Date.now()}-${pathname}`);
  const { default: worker } = await import(workerUrl.href);
  return worker.fetch(
    new Request(`http://localhost${pathname}`, { headers: { accept: "text/html" } }),
    { ASSETS: { fetch: async () => new Response("Not found", { status: 404 }) } },
    { waitUntil() {}, passThroughOnException() {} },
  );
}

test("server-renders the study entry routes in Slovene", async () => {
  const [home, adults, children] = await Promise.all([
    render("/"),
    render("/odrasli"),
    render("/otroci"),
  ]);
  for (const response of [home, adults, children]) {
    assert.equal(response.status, 200);
    assert.match(response.headers.get("content-type") ?? "", /^text\/html\b/i);
  }
  const homeHtml = await home.text();
  const adultHtml = await adults.text();
  const childHtml = await children.text();
  assert.match(homeHtml, /Različica za odrasle/);
  assert.match(homeHtml, /Različica za otroke/);
  assert.match(adultHtml, /Ali ste pripravljeni, da začnete nalogo\?/);
  assert.match(childHtml, /Ali si pripravljen\(a\), da začneš nalogo\?/);
  assert.match(adultHtml, /university-of-primorska-logo\.png/);
  assert.doesNotMatch(homeHtml, /codex-preview|react-loading-skeleton/i);
});

test("server-renders an English copy of the child study without changing the Slovene route", async () => {
  const [english, slovene] = await Promise.all([
    render("/children-english"),
    render("/otroci"),
  ]);
  assert.equal(english.status, 200);
  assert.equal(slovene.status, 200);
  const englishHtml = await english.text();
  const sloveneHtml = await slovene.text();
  assert.match(englishHtml, /Are you ready to begin the task\?/);
  assert.match(englishHtml, /Participant code/);
  assert.match(englishHtml, /I want to start the game and understand/);
  assert.doesNotMatch(englishHtml, /Ali si pripravljen|Šifra udeleženca/);
  assert.match(sloveneHtml, /Ali si pripravljen\(a\), da začneš nalogo\?/);
  assert.doesNotMatch(sloveneHtml, /Are you ready to begin the task\?/);
});

test("accepts English sessions while preserving the same experiment identity and materials", () => {
  const slovene = validInstructionSession();
  const english = validInstructionSession({
    language: "en",
    practice_demo: {
      ...slovene.practice_demo,
      rule_text: PRACTICE_RULE_ENGLISH_TEXT,
    },
  });
  assert.doesNotThrow(() => validateCheckpointRequest(validCheckpoint(english)));
  assert.equal(english.experiment_version, slovene.experiment_version);
  assert.equal(english.ruleset_version, slovene.ruleset_version);
  assert.deepEqual(english.rule_order, slovene.rule_order);
});

test("keeps the final rules and the split research schema in source", async () => {
  const [materials, component] = await Promise.all([
    readFile(new URL("../app/lib/experiment.ts", import.meta.url), "utf8"),
    readFile(new URL("../app/components/ZendoStudy.tsx", import.meta.url), "utf8"),
  ]);
  assert.match(materials, /V prizoru sta trikotnik in krog\./);
  assert.match(materials, /V prizoru je majhen zelen kvadrat\./);
  assert.match(materials, /active_tests:/);
  assert.match(materials, /generalisation_probes:/);
  assert.match(materials, /practice_demo:/);
  assert.match(materials, /PRACTICE_GENERALISATION_PROBES/);
  assert.match(materials, /operation_prompted: boolean/);
  assert.match(component, /operations_selected/);
  assert.match(component, /hypothesis_text/);
  assert.match(component, /anchor_scene_id/);
  assert.match(component, /experiment_version: CURRENT_EXPERIMENT_VERSION/);
  assert.match(materials, /object\("r2-p2-b", "red", "large", "circle", 1\)/);
  assert.match(materials, /object\("r3-i3", "blue", "large", "triangle", 2\)/);
  assert.match(materials, /object\("r4-i3", "red", "large", "triangle", 2\)/);
  assert.doesNotMatch(materials, /object\("r2-p2-a", "green", "large", "square", 0\)\) \}/);
  assert.doesNotMatch(component, /setPhase\("guess"\)/);
  assert.match(component, /trial\.final_rule_guess = finalRuleGuess\.trim\(\)/);
  assert.match(component, /trial\.final_rule_guess_at = nowIso\(\)/);
  assert.match(component, /isFinalActiveScene/);
  assert.match(component, /finalRuleGuess\.trim\(\)\.length >= 3/);
});

test("validates every displayed instruction example from the central materials", () => {
  assert.doesNotThrow(() => validateMaterials());
  assert.equal(PRACTICE_RULE.evaluate(PRACTICE_INITIAL_SCENE), true);
  assert.equal(INSTRUCTION_EXAMPLES.length, 3);
  for (const example of INSTRUCTION_EXAMPLES) {
    assert.equal(example.positiveScenes.length, 2, `${example.id} must have two positive scenes`);
    assert.equal(example.negativeScenes.length, 1, `${example.id} must have one negative scene`);
    assert.equal(example.positiveScenes.every((scene) => example.evaluate(scene)), true);
    assert.equal(example.negativeScenes.every((scene) => !example.evaluate(scene)), true);
  }
});

test("enforces the revised Bramley-style study sequence", async () => {
  const [component, materials] = await Promise.all([
    readFile(new URL("../app/components/ZendoStudy.tsx", import.meta.url), "utf8"),
    readFile(new URL("../app/lib/experiment.ts", import.meta.url), "utf8"),
  ]);
  assert.match(component, /Dobrodošel\(a\) v igri s planeta Zendo/);
  assert.match(component, /setPhase\("instructions"\)/);
  assert.match(component, /Začetni pozitivni primer · samo opazujte/);
  assert.match(component, /Nadaljujte na sestavljanje prizora/);
  assert.match(component, /Nov prazen prizor/);
  assert.match(component, /Začetni primer in vsi prejšnji prizori/);
  assert.doesNotMatch(component, /Predvajaj začetni primer/);
  assert.match(component, /isEnglish \? "Demonstration scene" : "Prikazni prizor"/);
  assert.match(component, /Kako izberete prizore, ki sledijo pravilu/);
  assert.match(component, /INSTRUCTION_EXAMPLES\.map/);
  assert.match(materials, /V prizoru je vsaj en velik lik/);
  assert.match(materials, /positiveScenes: \[/);
  assert.match(materials, /negativeScenes: \[/);
  assert.match(component, /PRACTICE_INITIAL_SCENE/);
  assert.match(component, /izberete lahko več opisov/i);
  assert.match(component, /type="checkbox" checked=\{operations\.includes\(operation\)\}/);
  assert.doesNotMatch(component, /type="radio" name="operation"/);
  assert.match(component, /const MAX_OBJECTS = MAX_SCENE_OBJECTS/);
  assert.match(component, /setPhase\("results"\)/);
  assert.match(component, /scene-result-star/);
  assert.match(component, /scene-slot/);
  assert.match(component, /rotate\(COLOUR_VALUES/);
  assert.doesNotMatch(component, /report-intro/);
  assert.doesNotMatch(component, /tipke Ctrl ni treba držati/);
  assert.doesNotMatch(component, /Poglejte, nato poskusite/);
  assert.doesNotMatch(component, /Prikaz za raziskovalca\(ko\)/);
  assert.match(materials, /Opiši, kaj drugega si želel\(a\) …/);
  assert.doesNotMatch(component, /\/-/);
  assert.doesNotMatch(materials, /\/-/);
});

test("keeps the space imagery and a non-sticky evidence strip at the top of the task", async () => {
  const [component, styles] = await Promise.all([
    readFile(new URL("../app/components/ZendoStudy.tsx", import.meta.url), "utf8"),
    readFile(new URL("../app/globals.css", import.meta.url), "utf8"),
  ]);
  assert.match(component, /renderEvidenceStrip\(true\)/);
  assert.match(component, /renderEvidenceStrip\(\)/);
  assert.match(styles, /space-background\.webp/);
  assert.match(component, /zendo-shapes-intro\.png/);
  assert.doesNotMatch(styles, /\.evidence-strip[^}]*position: sticky/);
});

test("uses the revised child opening and expanded Zendo story", async () => {
  const [component, styles] = await Promise.all([
    readFile(new URL("../app/components/ZendoStudy.tsx", import.meta.url), "utf8"),
    readFile(new URL("../app/globals.css", import.meta.url), "utf8"),
  ]);
  assert.doesNotMatch(component, /Igra odkrivanja pravil/);
  assert.doesNotMatch(component, /Odkrij skrivna pravila in prikliči zvezde/);
  assert.match(component, /Na planetu Zendo živijo posebni liki, glej spodaj\./);
  assert.match(component, /Zvezdice so torej povratna informacija o celotnem prizoru/);
  assert.match(component, /Na planetu Zorb so odkrili/);
  assert.match(component, /zendo-lab-two-platforms\.png/);
  assert.match(component, /Želim začeti igro in razumem, da jo lahko kadarkoli preneham igrati, če se ne počutim dobro/);
  assert.match(component, /<strong>sestavljal\(a\) prizore<\/strong>/);
  assert.match(component, /<strong>skrito pravilo<\/strong>/);
  assert.match(component, /<strong>izbral\(a\) boš opis operacije<\/strong>/);
  assert.match(component, /Ali vse skupine likov sledijo istemu pravilu\?/);
  assert.match(component, /width="1536" height="1024"/);
  assert.match(styles, /zendo-intro-image[^}]*color: transparent/);
  assert.match(component, /rule_order: shuffle\(RULES\.map/);
});

test("keeps proportional size scaling while making medium and large more distinct", async () => {
  const styles = await readFile(new URL("../app/globals.css", import.meta.url), "utf8");
  assert.match(styles, /scene-object--small \{ --shape-size: 50px; \}/);
  assert.match(styles, /scene-object--medium \{ --shape-size: 74px; \}/);
  assert.match(styles, /scene-object--large \{ --shape-size: 98px; \}/);
});

test("makes feedback, scene source choice, and quiz correction explicit", async () => {
  const [component, styles] = await Promise.all([
    readFile(new URL("../app/components/ZendoStudy.tsx", import.meta.url), "utf8"),
    readFile(new URL("../app/globals.css", import.meta.url), "utf8"),
  ]);
  assert.match(component, /function StarShower/);
  assert.match(component, /lastFeedback\.label \? <StarShower \/> : null/);
  assert.doesNotMatch(component, /star-shower--negative/);
  assert.match(styles, /@keyframes star-fall/);
  assert.match(styles, /prefers-reduced-motion: reduce/);
  assert.match(component, /Kako želite začeti ta prizor\?/);
  assert.match(component, /Izberite obstoječi prizor/);
  assert.match(component, /sourceChoice === "fresh" \|\| anchorSceneId !== null/);
  assert.match(component, /useState<"fresh" \| "existing" \| null>\(null\)/);
  assert.match(component, /const sourceReady = sourceChoice === "fresh" \|\| \(sourceChoice === "existing" && anchorSceneId !== null\)/);
  assert.match(component, /sourceReady \? <>/);
  assert.match(component, /source-waiting-card/);
  assert.match(styles, /grid-auto-columns: 180px/);
  assert.doesNotMatch(styles, /grid-auto-columns: minmax\(150px, 1fr\)/);
  assert.match(component, /history-result-star/);
  assert.doesNotMatch(component, /★ rumena zvezda|☆ bela zvezda/);
  assert.match(component, /Pravilen odgovor:/);
  assert.match(component, /comprehension_feedback_acknowledged/);
  assert.doesNotMatch(component, /Navodila preberite še enkrat/);
});

test("shows the fifth counterexample option with the approved order and exact Slovene labels", async () => {
  assert.deepEqual([...OPERATION_IDS], [
    "necessity",
    "sufficiency",
    "role_filler",
    "counterexample",
    "discovery",
    "other",
  ]);
  assert.deepEqual(OPERATION_LABELS.counterexample, {
    adult: "Naredili ste prizor, za katerega vaše trenutno pravilo napoveduje, da ne bo dobil zvezde, da bi preverili, ali jo bo vseeno dobil.",
    child: "Naredil(a) si prizor, za katerega tvoje trenutno pravilo napoveduje, da ne bo dobil zvezde, da bi preveril(a), ali jo bo vseeno dobil.",
  });

  const component = await readFile(new URL("../app/components/ZendoStudy.tsx", import.meta.url), "utf8");
  assert.match(component, /OPERATION_IDS\.map\(\(operation\) =>/);
  assert.match(component, /OPERATION_LABELS\[operation\]\[variant\]/);
  assert.match(component, /operations_selected: operationPrompted \? \[\.\.\.operations\] : \[\]/);
  assert.match(component, /primary_operation: operationPrompted \? operations\[0\] \?\? null : null/);
  assert.match(component, /operations\.length >= 1/);
  assert.match(component, /const operationPrompted = practiceEditorMode \|\| phase === "editor"/);
  assert.match(component, /experiment_version: CURRENT_EXPERIMENT_VERSION/);
});

test("round-trips new counterexample submissions and legacy four-option records losslessly", async () => {
  const newSession = {
    schema_version: "2.2.0",
    experiment_version: CURRENT_EXPERIMENT_VERSION,
    trials: [{
      active_tests: [{
        operation_prompted: true,
        operations_selected: ["counterexample"],
        primary_operation: "counterexample",
        other_operation_text: "",
      }],
    }],
  };
  const legacySession = {
    schema_version: "2.2.0",
    experiment_version: "zendo-simplified-1.6.2",
    trials: [{
      active_tests: [{
        operation_prompted: true,
        operations_selected: ["necessity", "discovery"],
        primary_operation: "necessity",
        other_operation_text: "",
      }],
    }],
  };

  for (const session of [newSession, legacySession]) {
    const stored = serializeStudySessionPayload(session);
    assert.deepEqual(parseStudySessionPayload(stored), session);
  }

  const [checkpointRoute, exportRoute] = await Promise.all([
    readFile(new URL("../app/api/checkpoint/route.ts", import.meta.url), "utf8"),
    readFile(new URL("../app/api/export/route.ts", import.meta.url), "utf8"),
  ]);
  assert.match(checkpointRoute, /payloadJson: serializeStudySessionPayload\(session\)/);
  assert.equal(
    checkpointRoute.match(/payloadJson: serializeStudySessionPayload\(session\)/g)?.length,
    2,
    "both initial insert and conflict update must use the same lossless serializer",
  );
  assert.match(exportRoute, /parseStudySessionPayload\(payloadJson\)/);
});

test("round-trips the frozen 1.6.2, 1.7.0, and 1.8.0 export fixtures byte-semantically", async () => {
  for (const fixtureName of ["zendo-session-1.6.2.json", "zendo-session-1.7.0.json", "zendo-session-1.8.0.json"]) {
    const raw = await readFile(new URL(`./fixtures/${fixtureName}`, import.meta.url), "utf8");
    const fixture = JSON.parse(raw);
    const stored = serializeStudySessionPayload(fixture);
    const exported = parseStudySessionPayload(stored);
    assert.deepEqual(exported, fixture);
  }

  const legacy = JSON.parse(await readFile(
    new URL("./fixtures/zendo-session-1.6.2.json", import.meta.url), "utf8",
  ));
  const pilot = JSON.parse(await readFile(
    new URL("./fixtures/zendo-session-1.7.0.json", import.meta.url), "utf8",
  ));
  const current = JSON.parse(await readFile(
    new URL("./fixtures/zendo-session-1.8.0.json", import.meta.url), "utf8",
  ));
  assert.equal(legacy.trials[0].active_tests[1].primary_operation, "discovery");
  assert.equal(pilot.trials[0].active_tests[1].primary_operation, "counterexample");
  assert.equal(current.trials[0].active_tests[0].operation_prompted, true);
  assert.equal(current.trials[0].active_tests[0].primary_operation, "counterexample");
  assert.deepEqual(current.trials[0].active_tests[0].operations_selected, ["counterexample"]);
  assert.equal(
    OPERATION_LABELS[current.trials[0].active_tests[0].primary_operation].adult,
    "Naredili ste prizor, za katerega vaše trenutno pravilo napoveduje, da ne bo dobil zvezde, da bi preverili, ali jo bo vseeno dobil.",
  );
});

test("only resumes unfinished sessions from the current five-option experiment", async () => {
  assert.equal(canResumeInCurrentExperiment({
    experiment_version: CURRENT_EXPERIMENT_VERSION,
    status: "active",
  }), true);
  assert.equal(canResumeInCurrentExperiment({
    experiment_version: "zendo-simplified-1.7.0",
    status: "active",
  }), false);
  assert.equal(canResumeInCurrentExperiment({
    experiment_version: "zendo-simplified-1.6.2",
    status: "active",
  }), false);
  assert.equal(canResumeInCurrentExperiment({
    experiment_version: CURRENT_EXPERIMENT_VERSION,
    status: "complete",
  }), false);

  const component = await readFile(new URL("../app/components/ZendoStudy.tsx", import.meta.url), "utf8");
  assert.match(component, /if \(!resumeCandidate \|\| !canResumeInCurrentExperiment\(resumeCandidate\.session\)\) return/);
  assert.match(component, /Prejšnje nedokončane seje ni mogoče nadaljevati, ker so se možnosti odgovorov spremenile\./);
  assert.match(component, /že shranjeni podatki bodo ostali v raziskovalnem izvozu/);
});

test("preserves in-progress report state and records the actual construction source exactly once", async () => {
  const component = await readFile(new URL("../app/components/ZendoStudy.tsx", import.meta.url), "utf8");
  for (const field of ["selectedIds", "hypothesis", "operations", "primaryOperation", "otherOperation"]) {
    assert.match(component, new RegExp(`${field}\\??:`));
    assert.match(component, new RegExp(`set${field[0].toUpperCase()}${field.slice(1)}\\(resumeCandidate\\.${field}`));
  }
  const prepareEditor = component.slice(
    component.indexOf("function prepareEditor"),
    component.indexOf("function beginEditor"),
  );
  assert.match(prepareEditor, /setActionEvents\(source \? \[/);
  assert.doesNotMatch(prepareEditor, /fresh_started/);
  const startFresh = component.slice(
    component.indexOf("function startFresh"),
    component.indexOf("function requestExistingSource"),
  );
  assert.match(startFresh, /event_type: "fresh_started"/);
});

test("checkpoint endpoint rejects malformed and version-drifted session identities", async () => {
  const [route, schema, revisionMigration] = await Promise.all([
    readFile(new URL("../app/api/checkpoint/route.ts", import.meta.url), "utf8"),
    readFile(new URL("../db/schema.ts", import.meta.url), "utf8"),
    readFile(new URL("../drizzle/0002_perfect_azazel.sql", import.meta.url), "utf8"),
  ]);
  assert.match(route, /validateCheckpointRequest\(parsed\)/);
  assert.match(route, /checkpointRevision/);
  assert.match(route, /Kontrolni zapis je zastarel\./);
  assert.match(route, /immutableSessionIdentity/);
  assert.match(route, /await db\.batch\(\[checkpointInsert, checkpointExportInsert, sessionUpdate\]\)/);
  assert.match(route, /exists\(exactCheckpointClaim\)/);
  assert.match(route, /eq\(studySessions\.lastCheckpointRevision, claimed\[0\]\.lastCheckpointRevision\)/);
  assert.match(route, /eq\(studySessions\.payloadJson, claimed\[0\]\.payloadJson\)/);
  assert.match(route, /FROM \$\{studySessions\}/);
  assert.match(route, /SELECT NULL, \$\{studyCheckpoints\.checkpointId\}/);
  assert.doesNotMatch(route, /db\.delete\(studyCheckpoints\)/);
  assert.match(route, /where\(eq\(studySessions\.sessionId, session\.session_id\)\)/);
  assert.match(route, /Identiteta seje se ne ujema\./);
  assert.match(route, /Neveljaven JSON\./);
  assert.match(schema, /uq_study_checkpoints_session_revision/);
  assert.match(revisionMigration, /CREATE UNIQUE INDEX `uq_study_checkpoints_session_revision`/);
  assert.match(revisionMigration, /checkpoint_revision" > 0/);
});

test("exports one stable keyset snapshot and stops repeated cursors", async () => {
  const [route, page, migration] = await Promise.all([
    readFile(new URL("../app/api/export/route.ts", import.meta.url), "utf8"),
    readFile(new URL("../app/izvoz/page.tsx", import.meta.url), "utf8"),
    readFile(new URL("../drizzle/0004_perfect_lady_vermin.sql", import.meta.url), "utf8"),
  ]);
  assert.match(route, /alias\(studyCheckpoints, "newer_checkpoint"\)/);
  assert.match(route, /notExists\(laterCheckpointInSnapshot\)/);
  assert.match(route, /orderBy\(asc\(studyCheckpoints\.sessionId\)\)/);
  assert.match(route, /checkpointSession\(row\.payloadJson, row\.sessionId\)/);
  assert.match(route, /cache-control": "no-store"/);
  assert.match(route, /next_cursor/);
  assert.match(route, /snapshot/);
  assert.match(route, /studyCheckpointExports\.sequence/);
  assert.match(route, /eq\(studyCheckpointExports\.sequence, suppliedSnapshot\.sequence\)/);
  assert.match(route, /Izvozni žig ne obstaja\./);
  assert.doesNotMatch(route, /snapshot\.created_at/);
  assert.match(migration, /PRIMARY KEY AUTOINCREMENT/);
  assert.match(migration, /INSERT INTO `study_checkpoint_exports`/);
  assert.match(page, /seenSessionIds/);
  assert.match(page, /seenCursors/);
  assert.match(page, /application\/x-ndjson/);
});

test("database export sequence excludes a later same-second UUID from an existing snapshot", async () => {
  const { DatabaseSync } = await import("node:sqlite");
  const migration = await readFile(
    new URL("../drizzle/0004_perfect_lady_vermin.sql", import.meta.url),
    "utf8",
  );
  const database = new DatabaseSync(":memory:");
  database.exec(`
    PRAGMA foreign_keys = ON;
    CREATE TABLE study_checkpoints (
      checkpoint_id text PRIMARY KEY NOT NULL,
      created_at text NOT NULL
    );
    INSERT INTO study_checkpoints VALUES
      ('ffffffff-ffff-4fff-8fff-ffffffffffff', '2026-08-17 10:00:00'),
      ('eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee', '2026-08-17 10:00:00');
  `);
  database.exec(migration.replaceAll("--> statement-breakpoint", ""));
  const snapshot = database.prepare(
    "SELECT MAX(sequence) AS sequence FROM study_checkpoint_exports",
  ).get().sequence;
  database.exec(`
    INSERT INTO study_checkpoints VALUES
      ('00000000-0000-4000-8000-000000000001', '2026-08-17 10:00:00');
    INSERT INTO study_checkpoint_exports (checkpoint_id)
      VALUES ('00000000-0000-4000-8000-000000000001');
  `);
  const visible = database.prepare(`
    SELECT checkpoint_id FROM study_checkpoint_exports
    WHERE sequence <= ? ORDER BY sequence
  `).all(snapshot).map((row) => row.checkpoint_id);
  assert.deepEqual(visible, [
    "eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee",
    "ffffffff-ffff-4fff-8fff-ffffffffffff",
  ]);
  database.close();
});

test("conditional checkpoint claim leaves no stale branch for export", async () => {
  const { DatabaseSync } = await import("node:sqlite");
  const database = new DatabaseSync(":memory:");
  database.exec(`
    PRAGMA foreign_keys = ON;
    CREATE TABLE study_sessions (
      session_id text PRIMARY KEY,
      last_checkpoint_revision integer NOT NULL,
      payload_json text NOT NULL
    );
    CREATE TABLE study_checkpoints (
      checkpoint_id text PRIMARY KEY,
      session_id text NOT NULL,
      checkpoint_revision integer NOT NULL,
      payload_json text NOT NULL,
      UNIQUE(session_id, checkpoint_revision),
      FOREIGN KEY(session_id) REFERENCES study_sessions(session_id)
    );
    CREATE TABLE study_checkpoint_exports (
      sequence integer PRIMARY KEY AUTOINCREMENT,
      checkpoint_id text UNIQUE NOT NULL,
      FOREIGN KEY(checkpoint_id) REFERENCES study_checkpoints(checkpoint_id)
    );
    INSERT INTO study_sessions VALUES ('session', 1, 'parent');
  `);
  const claim = database.prepare(`
    INSERT INTO study_checkpoints
    SELECT ?, session_id, ?, ? FROM study_sessions
    WHERE session_id = 'session'
      AND last_checkpoint_revision = ?
      AND payload_json = ?
    ON CONFLICT DO NOTHING
  `);
  const exportClaim = database.prepare(`
    INSERT INTO study_checkpoint_exports (checkpoint_id)
    SELECT checkpoint_id FROM study_checkpoints
    WHERE checkpoint_id = ? AND payload_json = ?
    ON CONFLICT DO NOTHING
  `);
  const advance = database.prepare(`
    UPDATE study_sessions SET last_checkpoint_revision = ?, payload_json = ?
    WHERE session_id = 'session'
      AND last_checkpoint_revision = ?
      AND payload_json = ?
      AND EXISTS (
        SELECT 1 FROM study_checkpoints
        WHERE checkpoint_id = ? AND payload_json = ?
      )
  `);

  database.exec("BEGIN");
  assert.equal(claim.run("winner", 2, "winner-payload", 1, "parent").changes, 1);
  assert.equal(exportClaim.run("winner", "winner-payload").changes, 1);
  assert.equal(advance.run(2, "winner-payload", 1, "parent", "winner", "winner-payload").changes, 1);
  database.exec("COMMIT");

  // A larger revision from the same stale parent arrives after the winner.
  // The conditional insert is already a no-op, so a crash needs no cleanup.
  database.exec("BEGIN");
  assert.equal(claim.run("stale", 3, "stale-payload", 1, "parent").changes, 0);
  assert.equal(exportClaim.run("stale", "stale-payload").changes, 0);
  assert.equal(advance.run(3, "stale-payload", 1, "parent", "stale", "stale-payload").changes, 0);
  database.exec("COMMIT");

  assert.deepEqual(database.prepare(
    "SELECT checkpoint_id FROM study_checkpoints ORDER BY checkpoint_id",
  ).all().map((row) => row.checkpoint_id), ["winner"]);
  assert.deepEqual(database.prepare(
    "SELECT checkpoint_id FROM study_checkpoint_exports ORDER BY sequence",
  ).all().map((row) => row.checkpoint_id), ["winner"]);
  database.close();
});

test("validates checkpoint payloads deeply and freezes session identity", () => {
  const body = validCheckpoint();
  assert.deepEqual(validateCheckpointRequest(body), body);
  assert.equal(isStudySessionPayload(body.session), true);

  for (const mutate of [
    (copy) => { copy.session.rule_order = [1, 1, 3, 4, 5]; },
    (copy) => { copy.session.device.viewport_width = Number.NaN; },
    (copy) => { copy.session.completion_code = "not-a-code"; },
    (copy) => { delete copy.checkpoint_revision; },
    (copy) => { copy.client_timestamp = "2026-08-17"; },
    (copy) => { copy.checkpoint_type = "session_completed"; },
    (copy) => { copy.session.last_checkpoint_at = "2026-08-17T10:00:01.000Z"; },
  ]) {
    const adversarial = structuredClone(body);
    mutate(adversarial);
    assert.throws(() => validateCheckpointRequest(adversarial));
  }

  const changed = structuredClone(body.session);
  changed.participant_code = "AUDIT-002";
  assert.notEqual(immutableSessionIdentity(changed), immutableSessionIdentity(body.session));
});

test("rejects valid session snapshots carrying impossible checkpoint transition labels", () => {
  const impossibleTypes = [
    "practice_demo_started",
    "practice_generalisation_started",
    "practice_demo_completed",
    "instructions_completed",
    "comprehension_reviewed",
  ];
  for (const checkpointType of impossibleTypes) {
    const body = validCheckpoint();
    body.checkpoint_type = checkpointType;
    assert.throws(
      () => validateCheckpointRequest(body),
      /ne opisuje|ne vsebuje/,
      checkpointType,
    );
  }

  const resumed = validCheckpoint();
  resumed.checkpoint_type = "session_resumed";
  resumed.trial_index = 0;
  assert.throws(() => validateCheckpointRequest(resumed), /obnovljene/);

  const mislabeledStart = validCheckpoint();
  mislabeledStart.session.practice_demo.started_at = "2026-08-17T10:00:00.000Z";
  assert.throws(() => validateCheckpointRequest(mislabeledStart), /nove seje/);
});

test("rejects a valid higher-revision snapshot that rewrites saved session history", () => {
  const previous = validInstructionSession({
    practice_demo: {
      ...validInstructionSession().practice_demo,
      started_at: "2026-08-17T10:00:01.000Z",
    },
  });
  const forward = structuredClone(previous);
  forward.resume_count = 1;
  assert.doesNotThrow(() => validateSessionProgression(previous, forward));

  const divergent = structuredClone(forward);
  divergent.practice_demo.started_at = null;
  assert.equal(isStudySessionPayload(divergent), true);
  assert.throws(
    () => validateSessionProgression(previous, divergent),
    /ne sme spremeniti/,
  );
});

test("lossless session serialization rejects values JSON would silently coerce", () => {
  for (const payload of [
    { value: undefined },
    { value: Number.NaN },
    { value: Number.POSITIVE_INFINITY },
    { value: -0 },
    { value: 1n },
    { value: new Date("2026-08-17T10:00:00.000Z") },
  ]) {
    assert.throws(() => serializeStudySessionPayload(payload), /JSON|non-JSON|non-plain/);
  }
});

test("permits an explicit empty main generalisation selection", async () => {
  const component = await readFile(new URL("../app/components/ZendoStudy.tsx", import.meta.url), "utf8");
  const submit = component.slice(
    component.indexOf("function submitGeneralisation"),
    component.indexOf("function submitDemographics"),
  );
  assert.doesNotMatch(submit, /some\(\(probe\) => probe\.selected\)/);
  assert.match(component, /Če menite, da ne sledi noben, ne izberite nobenega\./);
});

test("does not show completion until the final server checkpoint succeeds", async () => {
  const component = await readFile(new URL("../app/components/ZendoStudy.tsx", import.meta.url), "utf8");
  const submit = component.slice(
    component.indexOf("async function submitDemographics"),
    component.indexOf("function renderWelcome"),
  );
  assert.match(submit, /const result = await checkpoint\(completed, "session_completed"/);
  assert.match(submit, /if \(!result\.ok\)/);
  assert.ok(submit.indexOf('setPhase("complete")') > submit.indexOf("if (!result.ok)"));
});
